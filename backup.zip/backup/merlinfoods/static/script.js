// managing tabs
    function showContent(contentType) {
        // Hide all content divs
        document.getElementById('home-content').style.display = 'none';
        document.getElementById('foods-content').style.display = 'none';
        document.getElementById('restaurants-content').style.display = 'none';
        document.getElementById('order-content').style.display = 'none';
        document.getElementById('service-content').style.display = 'none';
        document.getElementById('contact-content').style.display = 'none';
        document.getElementById('about-content').style.display = 'none';
        document.getElementById('login-content').style.display = 'none';
        document.getElementById('signup-content').style.display = 'none';
        document.getElementById('search').style.display = 'none';

        document.getElementById('viewrestaurant-content').style.display = 'none';

        document.getElementById('showname').style.display = 'none';


        document.getElementById('hidename').style.display = 'flex';
        document.getElementById('hidemenu').style.display = 'flex';
        // document.getElementById('hidelogin').style.display = 'flex';
        // document.getElementById('hideorder').style.display = 'flex';




        // Show the selected content
        if (contentType === 'foods') {
            document.getElementById('foods-content').style.display = 'block';
            document.getElementById('hidemenu').style.display = 'none';
            document.getElementById('hideorder').style.display = 'flex';
            document.getElementById('search').style.display = 'flex';



        } else if (contentType === 'restaurants') {
            document.getElementById('restaurants-content').style.display = 'block';
            document.getElementById('hidename').style.display = 'none';
            document.getElementById('hidemenu').style.display = 'none';
            // document.getElementById('hidelogin').style.display = 'none';
            // document.getElementById('hideorder').style.display = 'none';
            document.getElementById('showname').style.display = 'flex';

        } else if (contentType === 'main') {
            document.getElementById('home-content').style.display = 'block';
        } else if (contentType === 'service') {
            document.getElementById('service-content').style.display = 'block';
        } else if (contentType === 'about') {
            document.getElementById('about-content').style.display = 'block';
        } else if (contentType === 'contact') {
            document.getElementById('contact-content').style.display = 'flex';
        } else if (contentType === 'order') {
            document.getElementById('order-content').style.display = 'block';
        } else if (contentType === 'login') {
            document.getElementById('login-content').style.display = 'block';
        } else if (contentType === 'signup') {
            document.getElementById('signup-content').style.display = 'block';
        } else if (contentType === 'viewrestaurant') {
            document.getElementById('viewrestaurant-content').style.display = 'block';
        }
    }

    // open sidenav

    // function sidenav(){
    //     document.getElementById('menu').style.width ='21%'
    //     document.getElementById('menu_bar').style.display ='none'

    // }
    // function closesidenav(){
    //     document.getElementById('menu').style.width = '0%'
    //     document.getElementById('menu').style.width = '0%'

    // }
    //cart

    function opencart(){
        const cartWidget = document.getElementById('checkout');
        if ( cartWidget.style.width <= "0%"){
            cartWidget.style.width = "30%"
        } else {
            cartWidget.style.width = "0%"
        }
    }
    // close side nav
    function sidenav(){
        const sideWidget = document.getElementById('menu');
        if ( sideWidget.style.width <= "0%"){
            sideWidget.style.width = "21%"
        } else {
           sideWidget.style.width = "0%"
        }
    }

    // open profile
    function openProfile(){
        const profileWidget = document.getElementById('profiles');
        if ( profileWidget.style.width <= "0%"){
            profileWidget.style.width = "18%"
        } else {
            profileWidget.style.width = "0%"
        }
    }
    // open orders
    function openOrders(){
        document.getElementById('openorder').style.display = 'block'
        document.getElementById('profiles').style.width = '0%'
    }

    
    // open delivery page
    function openOrder(){
        document.getElementById('cartOrder').style.display = "block"
        document.getElementById('checkout').style.width = "0%";
        postOrder();
    }
    
    // back to cart
    function backtocart(){
        document.getElementById('checkout').style.width = "30%"
        document.getElementById('cartOrder').style.display = "none"
        
    }

        // post order
        function postOrder(){
            const orderList = [];   
            const orders_name = document.querySelectorAll(".ordered_food_name");
            const orders_restaurant = document.querySelectorAll(".ordered_restaurant_name");
            const orders_price = document.querySelectorAll(".ordered_price_name");
            const email = document.querySelectorAll(".user_email");
            const amount = document.querySelectorAll(".number_counter");
            orders_name.forEach(function(item, index){
                alert(email[index].innerHTML)
                orderList.push(
                    {
                        "name": item.innerHTML,
                        "restaurant": orders_restaurant[index].innerHTML,
                        "amount": amount[index].innerHTML,
                        "price": orders_price[index].innerHTML,
                        "email":email[index].innerHTML
                    }
                );
            })
            console.log(orderList);

            // convert the data into form data
            orderList.forEach(function(data, index){
                const formData = new FormData();
                for (const key in data) {
                    formData.append(key, data[key]);
                }
        
                // fetch API to send the POST request
                fetch("http://localhost/merlinfoods/post_order.php", {
                    method: "POST",
                    body: formData
                })
                .then(response => response.json()) // Assuming the server responds with JSON
                .then(data => console.log('Success:', data))
                .catch(error => console.error('Error:', error));

            })
        }

    // totla cost
    var itemPriceElement = document.querySelector('.itemprice .iprice');
        var deliveryPriceElement = document.querySelector('.dprice .deliv');
        var totalPriceElement = document.querySelector('.tprice .tota');

        var itemPrice = parseFloat(itemPriceElement.textContent.trim()) || 0;
        var deliveryPrice = parseFloat(deliveryPriceElement.textContent.trim()) || 0;

        var totalPrice = itemPrice + deliveryPrice;

        totalPriceElement.textContent = totalPrice.toFixed(2); 

        // date and time
        var currentDate = new Date();
        var estdateElement = document.getElementById('estdate');
        var esttimeElement = document.getElementById('esttime');

        // Update estdate with the current date
        estdateElement.textContent = currentDate.toLocaleDateString();

        // Update esttime with the current time + 30 minutes
        currentDate.setMinutes(currentDate.getMinutes() + 30);
        var hours = currentDate.getHours();
        var minutes = currentDate.getMinutes();

        esttimeElement.textContent = (hours < 10 ? '0' : '') + hours + ':' + (minutes < 10 ? '0' : '') + minutes;


    // //    open profile
    // function openProfile(){
    //     document.getElementById('profiles').style.display = 'block'
    // }