<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Navigation Page</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
        }

        nav {
            background-color: #333;
            color: white;
            padding: 10px;
        }

        #sidebar {
            position: fixed;
            left: -250px; /* Hide the sidebar initially */
            top: 0;
            bottom: 0;
            width: 250px;
            background-color: #f0f0f0;
            transition: left 0.3s ease;
        }

        #sidebar ul {
            list-style-type: none;
            padding: 0;
        }

        #sidebar li {
            padding: 10px;
        }

        main {
            margin-left: 250px; /* Adjust this margin to accommodate the sidebar */
            padding: 20px;
        }

        /* Style the sidebar toggle button */
        #toggleSidebar {
            display: none; /* Hide the button on larger screens */
        }

        /* Show the sidebar button on smaller screens */
        @media (max-width: 768px) {
            #toggleSidebar {
                display: block;
            }

            #sidebar {
                left: 0;
            }

            main {
                margin-left: 0;
            }
        }
    </style>
</head>
<body>
    <nav>
        <button id="toggleSidebar">Toggle Sidebar</button>
    </nav>
    <div id="sidebar">
        <ul>
            <li><a href="#">Home</a></li>
            <li><a href="#">About</a></li>
            <li><a href="#">Services</a></li>
            <li><a href="#">Contact</a></li>
        </ul>
    </div>
    <main>
        <!-- Your main content here -->
        <h1>Welcome to My Website</h1>
        <p>This is the main content area. You can add your content here.</p>
    </main>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const toggleSidebarButton = document.getElementById('toggleSidebar');
            const sidebar = document.getElementById('sidebar');

            toggleSidebarButton.addEventListener('click', function() {
                sidebar.classList.toggle('active');
            });
        });
    </script>
</body>
</html>
