<?php
// Include database connection
include('db_connection.php');

// Check if start and end dates are provided via GET parameters
if (isset($_GET['start_date']) && isset($_GET['end_date'])) {
    // Sanitize input to prevent SQL injection
    $start_date = mysqli_real_escape_string($conn, $_GET['start_date']);
    $end_date = mysqli_real_escape_string($conn, $_GET['end_date']);
    echo $end_date;

    // SQL query to retrieve orders within the specified date range
    $sql = "SELECT `cartID`, `email`, `itemName`, `itemRestaurant`, `itemPrice`, `amount`, `date`, `status` 
            FROM `cart` 
            WHERE DATE(`date`) BETWEEN ? AND ?";
    $stmt = $conn->prepare($sql);

    if ($stmt) {
        // Bind parameters
        $stmt->bind_param("ss", $start_date, $end_date);

        // Execute the statement
        if ($stmt->execute()) {
            // Fetch the result
            $result = $stmt->get_result();

            // Check if there are any orders
            if ($result->num_rows > 0) {
                // Output CSV headers
                header('Content-Type: text/csv');
                header('Content-Disposition: attachment; filename="orders_report.csv"');
                header('Pragma: no-cache');
                header('Expires: 0');

                // Open file handle
                $output = fopen('php://output', 'w');

                // Write CSV headers
                fputcsv($output, array('Cart ID', 'Email', 'Item Name', 'Restaurant', 'Item Price', 'Amount', 'Date', 'Status'));

                // Loop through the orders and write data to CSV
                while ($row = $result->fetch_assoc()) {
                    fputcsv($output, array($row['cartID'], $row['email'], $row['itemName'], $row['itemRestaurant'], $row['itemPrice'], $row['amount'], $row['date'], $row['status']));
                }

                // Close file handle
                fclose($output);
                exit();
            } else {
                // No orders found in the specified date range
                echo "No orders found for the specified date range.";
            }
        } else {
            // Error executing the statement
            echo "Error executing SQL statement: " . $stmt->error;
        }
    } else {
        // Error preparing the statement
        echo "Error preparing SQL statement: " . $conn->error;
    }
} else {
    // Start and end dates not provided
    echo "Start and end dates not provided.";
}

// Close the database connection
$conn->close();
?>
