<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="static/index.css">
</head>
<body>

<div class="login_page">
                    <div class="signup_form">
                        <!-- <div id="registrationMessage">hey</div> -->
                        <form action="users_reg.php" method="POST"class="owner_logins" onsubmit="return validateForm()">
                            <div class="signame"  id="registrationMessage">Create New Account</div><br>
                                <input type="text" name="first_name" placeholder="Enter your First Name" required><br><br>
                                <input type="text" name="last_name" placeholder="Enter your Second Name" required><br><br>
                                <input type="text" name="username" placeholder="Choose a Username" required><br> <br>
                                <input type="email" name="email" placeholder="Enter Your Email" required><br><br>
                                <input type="text" name="telephone" placeholder="Enter your Telephone"pattern="[0-9]{10}" required><br><br>
                                <input type="text" name="address" placeholder="Enter your Address" required><br><br>
                                <input type="password" name="password" placeholder="Enter your password"minlength="6" required><br><br>
                                <input type="submit" value="Signup"style="padding:15px 86px;background-color:green;color:white;"><br>
                                <div class="bottom_login"> Already have an account? <br><a href="login_page.php">Login</a></div>
                            </form>
                    </div>                
                </div>

</body>
</html>