<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>foods</title>
</head>
<body>
    <?php
    include "base.php"
    ?>
    <div class="main_bar">
        <div class="tab_content active" id="foodsContent">
            <div class="top_bar">
                <div class="bar_name">
                    Foods
                </div>
            </div>
            <div class="foods_header">
                <ul>
                    <li>Food Image</li>
                    <li>Food ID</li>
                    <li>Food Name</li>
                    <li>Food Price</li>
                    <li>Actions</li>
                </ul>
            </div>
            <div class="foods_display">
                <?php
                include('db_connection.php');

                // Get the logged-in restaurant name
                $restaurant_name = $_SESSION['restaurant_name'];

                // Query to retrieve food_id, food_image, food_name, and price for the logged-in restaurant
                $sql = "SELECT food_id, food_image, food_name, price FROM foods WHERE restaurant_name = '$restaurant_name'";
                $result = $conn->query($sql);

                // Check if there are any results
                if ($result->num_rows > 0) {
                    // Output data of each row
                    while ($row = $result->fetch_assoc()) {
                        // Access data using associative array keys
                        $food_id = $row['food_id'];
                        $food_image = $row['food_image'];
                        $food_name = $row['food_name'];
                        $price = $row['price'];
                ?>
                <ul>
                    <li><img src="<?php echo $food_image; ?>" alt="" width="80px" height="100%" style="border-radius: 8px;"></li>
                    <li><?php echo $food_id; ?></li>
                    <li><?php echo $food_name; ?></li>
                    <li>Kshs <?php echo $price; ?></li>
                    <li style="display: flex; gap:16px;">
                        <i class="fa fa-pencil" onclick="toggleForm(<?php echo $food_id; ?>)"></i>
                        <i class="fa fa-trash" onclick="deleteFood(<?php echo $food_id; ?>)"></i>
                    </li>
                </ul>
        <!-- Update Form for Food -->
        <form id="updateForm_<?php echo $food_id; ?>" class="update-form" style="display: none;" action="update_food.php" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="food_id" value="<?php echo $food_id; ?>">
            <div class="form-group">
                <label for="food_name">Food Name:</label>
                <input type="text" id="food_name" name="food_name" value="<?php echo $food_name; ?>" required>
            </div>
            <div class="form-group">
                <label for="food_image">Food Image:</label><br>
                <img src="<?php echo $food_image; ?>" alt="Previous Image" width="100"><br>
                <input type="file" id="food_image" name="food_image">
            </div>

            <div class="form-group">
                <label for="price">Price:</label>
                <input type="number" id="price" name="price" value="<?php echo $price; ?>" required><br>
            </div>
            <button type="submit">Update Food</button>
            <!-- Success/Error messages -->
            <?php
            if(isset($_GET['success'])) {
                $successMessage = $_GET['success'];
                echo "<p class='success-message'>$successMessage</p>";
            }
            if(isset($_GET['error'])) {
                $errorMessage = $_GET['error'];
                echo "<p class='error-message'>$errorMessage</p>";
            }
            ?>
        </form>
                <?php
                    }
                } else {
                    echo "No results found.";
                }

                // Close the database connection
                $conn->close();
                ?>
            </div>

            <!-- Add FOODS -->
            <div class="add_foods" id="add_foods">
                <form action="insert_data.php" method="post" enctype="multipart/form-data">
                    <!-- <div class="form-name">Add Foods</div> -->
                    <div class="food-menu">Food menu</div>
                    <select id="food_menu" name="food_menu" required>
                        <option value="breakfast">Breakfast</option>
                        <option value="lunch">Lunch</option>
                        <option value="dinner">Dinner</option>
                        <option value="snack">Snack</option>
                        <option value="drinks">Drinks</option>
                    </select><br>
                    <div class="food-name">Food Name</div>
                    <input type="text" id="food_name" name="food_name" required><br>
                    
                    <div class="food-image">Food Image</div>
                    <input type="file" id="food_image" name="food_image" accept="image/*" required><br>
                    
                    <div class="food-price">Food Price</div>
                    <input type="text" id="price" name="price" required><br>
            
                    <input type="submit" value="Add Food" class="add">

                    <?php
             // Check if success message is present in session
            if(isset($_SESSION['success'])) {
                $successMessage = $_SESSION['success'];
                echo "<p style='color:green;'>$successMessage</p>";
                unset($_SESSION['success']); // Clear the success message
            }
            ?>
                </form>
            </div>
            </div>
            <div class="add_new_foods"><i class="fa fa-plus" onclick="openPlus()"></i></div>
    </div>
</body>
</html>

