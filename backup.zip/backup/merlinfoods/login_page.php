<?php
    // Retrieve login response from the session
    session_start();
    $loginResponse = isset($_SESSION['login_response']) ? $_SESSION['login_response'] : null;
    // Clear the session variable to avoid displaying the same message on page reload
    unset($_SESSION['login_response']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="static/index.css">
</head>
<body>
    <div class="login_page">
        <div class="login_form">
            <div class="logname" id="loginMessage">
                <script>
                    // Display login response message using JavaScript
                    var loginResponse = <?php echo json_encode($loginResponse); ?>;
                    document.getElementById("loginMessage").innerText = loginResponse ? loginResponse.message : "";
                </script>
            </div>
            <form id="loginForm" action="login_process.php" method="POST" class="owner_logins">
                <h2>login</h2>
                <input type="email" name="email" placeholder="Email"><br><br>
                <input type="password" name="password" placeholder="Enter your password"><br><br>
                <input type="submit" value="Login" style="padding:15px 88px;background-color:green;color:white;"><br><br>
                <div class="bottom_login"> 
                    Don't have an account? <br>
                    <div><a href="signup_page.php">Create Account</a></div>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
