<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Restaurant Registration</title>
    <link rel="stylesheet" href="static/index.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

</head>
<body>
    <div class="login_page">
        <form action="register.php" method="post" class="owner_logins" enctype="multipart/form-data">
        
            <h1>Restaurant Registration</h1><br>
            <input type="text" id="restaurant_name" name="restaurant_name" required placeholder="restaurant name"><br><br>
            <input type="file" id="restaurant_image" name="restaurant_image" accept="image/*" required><br><br>
            <input type="text" id="food_description" name="food_description" required placeholder="food description"><br><br>
            <input type="password" id="password" name="password" required placeholder="password"><br><br>
            <input type="text" id="phone_number" name="phone_number" required placeholder="phone number"> <br><br>
            <input type="email" id="email" name="email" required placeholder="email"><br><br>
            <input type="text" id="address" name="address" required placeholder="address"><br><br>
            <input type="submit" value="Register Restaurant"style="padding:15px 50px;background-color:green;color:white;"><br><br>
            <p>Already have an account?<a href="restaurant_loginn.php">login</a></p>
            
        </form>
    
    </div>
</body>
</html>
