<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="static/admin.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.17.4/xlsx.full.min.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.7.0/chart.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
    <div class="admin_page">
        <div class="side_bar">
            <div class="company_name">MERLIN FOOD <br> <p>DELIVERY</p></div>
            <div class="myrestaurant" style="background-image: url(./images/ashley.png);background-size: cover; background-position: center; background-repeat: no-repeat; width: 80%; height: 25%;margin-left:10%;border-radius:10px;">
            <div class="restaurant_name">AdMIN</div>
            </div>
            <ul>
                <li onclick="openTab('dashboard')"><div class="lists"><i class="fa fa-dashboard"></i> Dashboard</div></li>
                <li><a href="restaurant_loginn.php" class="lists"><i class="fa fa-cutlery"></i> Restaurants</a></li>
                <li onclick="openTab('users')"><div class="lists"><i class="fa fa-user-circle"></i> Users</div></li>
                <li onclick="openTab('messages')"><div class="lists"><i class="fa fa-envelope"></i> Messages</div></li>
                <!-- <li onclick="openTab('users')"> <div class="lists"><i class="fa fa-shopping-cart"></i> Orders</div></li> -->
                 <!-- <li onclick="openTab('transactions')"><div class="lists"><i class="fa fa-exchange"></i> Transactions</div></li>  -->
            </ul>
            <!-- jj -->
            
            <hr>
            
        </div>
        <div class="main_bar">
            <!-- dashboard -->
            <div class="tab_content active " id="dashboardContent">
                <div class="top_bar">
                    <div class="bar_name">
                        Dashboard
                    </div>
                    <style>
                        .accs{
                            display: flex;
                            gap: 5px;
                            position: absolute;
                            right: 1%;
                            top: 7%;
                        }

                        /* Style the button */
    #downloadBtn {
        background-color: #4CAF50; /* Green background color */
        border: none; /* Remove border */
        color: white; /* White text color */
        padding: 10px 20px; /* Add padding */
        text-align: center; /* Center text */
        text-decoration: none; /* Remove underline */
        display: inline-block; /* Make it inline */
        font-size: 16px; /* Set font size */
        cursor: pointer; /* Add pointer cursor on hover */
        border-radius: 5px; /* Add border-radius for rounded corners */
        transition: background-color 0.3s ease; /* Smooth transition for background color */
    }

    /* Style the button hover state */
    #downloadBtn:hover {
        background-color: #45a049; /* Darker green on hover */
    }
                    </style>
                    <div class="accs">
                <div>
                    welcome admin
                </div>
                <div>
                    <a href="adminlogout.php">Logout</a>
                </div>
            </div>
                </div> 
               <div class="dashboard_boxes">
               <?php
                // Include the database connection file
                include('db_connection.php');

                // Count rows in restaurants table
                $sql_restaurants = "SELECT COUNT(*) AS restaurant_count FROM restaurants";
                $result_restaurants = $conn->query($sql_restaurants);
                $row_restaurants = $result_restaurants->fetch_assoc();
                $restaurant_count = $row_restaurants['restaurant_count'];

                //obeyia

                    // Count rows in mails table
                $sql_mails = "SELECT COUNT(*) AS mail_count FROM mails";
                $result_mails = $conn->query($sql_mails);
                $row_mails = $result_mails->fetch_assoc();
                $mail_count = $row_mails['mail_count'];


                // Count rows in users table
                $sql_users = "SELECT COUNT(*) AS user_count FROM users";
                $result_users = $conn->query($sql_users);
                $row_users = $result_users->fetch_assoc();
                $user_count = $row_users['user_count'];

                // Sum total amount from transactions table
                $sql_total_amount = "SELECT SUM(total_amount) AS total_sum FROM transactions";
                $result_total_amount = $conn->query($sql_total_amount);
                $row_total_amount = $result_total_amount->fetch_assoc();
                $total_sum = $row_total_amount["total_sum"];

                // Sum total salary from staffs table
                $sql_total_salary = "SELECT SUM(salary) AS total_salary FROM staffs";
                $result_total_salary = $conn->query($sql_total_salary);
                $row_total_salary = $result_total_salary->fetch_assoc();
                $total_salary = $row_total_salary["total_salary"];

                // Calculate remaining balance
                $remaining_balance = $total_sum - $total_salary;

                // Calculate profit/loss
                $profit_loss = $total_sum - $total_salary;

                // Prepare data for Chart.js
                $chart_data = [
                    'labels' => ['Total Amount', 'Expenses', 'Profit','loss'],
                    'datasets' => [
                        [
                            'label' => 'Amount',
                            'backgroundColor' => ['blue', 'red', 'green'],
                            'data' => [$total_sum, $total_salary, $profit_loss]
                        ]
                    ]
                ];
                
                ?>
                    <div class="boxes">Restaurants<br><?php echo $restaurant_count; ?></div>
                    <div class="boxes">Users<br><?php echo $user_count; ?></div>
                    <div class="boxes">Messages<br><?php echo $mail_count; ?></div>
                    <div class="boxes">Total sales<br><?php echo $total_sum; ?></div>
                    <div class="boxes">expenses<br><?php echo $total_salary; ?></div>
                    <div class="boxes">Profit<br><?php echo $remaining_balance; ?></div>
                    <!-- <div class="boxes">Pending <br>0</div> -->
                    <!-- <div class="boxes">Delivered <br>0</div> -->

               </div> 
               <div class="bottom">
                    <div class="aob">
                    <div class="filter">
                        <!-- obeyiaa -->
                       <label for="start_date">Start Date:</label>
                        <input type="date" id="start_date" name="start_date">

                        <label for="end_date">End Date:</label>
                        <input type="date" id="end_date" name="end_date">

                        <button onclick="filterData()">filter</button>

                        <!--  Download CSV button -->
                         <!--<a id="download_csv" href="#" download="report.csv">Download CSV</a> -->
                         <button id="downloadBtn">Download Data</button>

                    </div>
                        <canvas id="profitLossChart"></canvas>
                        <script>
    // Render profit/loss Chart.js chart
    var ctxProfitLoss = document.getElementById('profitLossChart').getContext('2d');
    var chartDataProfitLoss = <?php echo json_encode($chart_data); ?>;
    var myChartProfitLoss = new Chart(ctxProfitLoss, {
        type: 'bar',
        data: {
            labels: chartDataProfitLoss.labels,
            datasets: chartDataProfitLoss.datasets
        }
    });

   // Function to filter data by date range and update chart
function filterData() {
    var startDate = document.getElementById('start_date').value;
   var endDate = document.getElementById('end_date').value;

    //Send selected date range to PHP for filtering
    var url = 'filter_data.php?start_date=' + startDate + '&end_date=' + endDate;
    fetch(url)
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            // Update chart data
            myChartProfitLoss.data.labels = ['Revenue', 'Expenses', 'Profit','loss'];
            myChartProfitLoss.data.datasets[0].data = [data.total_amount, data.total_salary, data.profit];
            myChartProfitLoss.update();
        })
        .catch(error => {
            console.error('Error:', error);
        });
}
</script>
                    </div>
                    <!-- obeyia -->
                    <!-- <div class="graph"> -->
                        <!-- <canvas id="lineChart" width="400" height="200" style="margin-top:15px;"></canvas> -->
                        <script>
                        // Sample data for restaurants and users over time
                        // const data = {
                        //     labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May'],
                        //     datasets: [
                        //     {
                        //         label: 'Restaurants',
                        //         data: [10, 15, 20, 18, 25], // Number of restaurants for each month
                        //         borderColor: 'rgb(255, 99, 132)',
                        //         fill: false
                        //     },
                        //     {
                        //         label: 'Usert',
                        //         data: [50, 55, 60, 58, 65], // Number of users for each month
                        //         borderColor: 'rgb(54, 162, 235)',
                        //         fill: false
                        //     }
                        //     ]
                        // };

                        // Chart configuration
                        // const config = {
                        //     type: 'line',
                        //     data: data,
                        //     options: {
                        //     scales: {
                        //         x: {
                        //         display: true,
                        //         title: {
                        //             display: true,
                        //             text: 'Month'
                        //         }
                        //         },
                        //         y: {
                        //         display: true,
                        //         title: {
                        //             display: true,
                        //             text: 'Count'
                        //         }
                        //         }
                        //     }
                        //     }
                        // };

                        // Create a line chart
                        // const ctx = document.getElementById('lineChart').getContext('2d');
                        // new Chart(ctx, config);
                        </script>                        
                    </div>
                </div>
            </div>

            <!-- restaurants-->
            <div class="tab_content " id="restaurantsContent">
                <div class="top_bar">
                    <div class="bar_name">
                            restaurants
                    </div>
                    <style>
                        .accs{
                            display: flex;
                            gap: 5px;
                            position: absolute;
                            right: 1%;
                            top: 7%;
                        }
                    </style>
                    <div class="accs">
                <div>
                    welcome admin
                </div>
                <div>
                    <a href="adminlogout.php">Logout</a>
                </div>
            </div>

                </div>
                <div class="restaurant_area">
                <?php
                    include('db_connection.php');

                    // Check if the delete request is submitted
                    if(isset($_POST['delete_restaurant'])){
                        // Get the restaurant name to be deleted
                        $restaurant_name_to_delete = $_POST['delete_restaurant'];

                        // Prepare and execute the SQL statement to delete the restaurant
                        $delete_sql = "DELETE FROM restaurants WHERE restaurant_name = ?";
                        $stmt = $conn->prepare($delete_sql);
                        $stmt->bind_param("s", $restaurant_name_to_delete);
                        if ($stmt->execute()) {
                            echo "<script>alert('Restaurant deleted successfully.');</script>";
                        } else {
                            echo "<script>alert('Error: Unable to delete restaurant.');</script>";
                        }
                    }

                    // Prepare SQL statement to retrieve restaurant details
                    $sql = "SELECT restaurant_name, restaurant_image, food_description, phone_number, email, address FROM restaurants";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        // Output table header
                        echo '<table border="1">';
                        echo '<tr><th>Restaurant Name</th><th>Food Description</th><th>Phone Number</th><th>Email</th><th>Address</th><th>Action</th></tr>';

                        // Output data of each row
                        while ($row = $result->fetch_assoc()) {
                            echo '<tr>';
                            echo '<td>' . $row['restaurant_name'] . '</td>';
                            echo '<td>' . $row['food_description'] . '</td>';
                            echo '<td>' . $row['phone_number'] . '</td>';
                            echo '<td>' . $row['email'] . '</td>';
                            echo '<td>' . $row['address'] . '</td>';
                            echo '<td>';
                            // Add delete button with confirmation
                            echo '<form id="deleteForm" method="post">';
                            echo '<input type="hidden" name="delete_restaurant" value="' . $row['restaurant_name'] . '">';
                            echo '<button type="submit" onclick="return confirmDelete()"><i class="fa fa-trash"></i></button>';
                            echo '</form>';
                            echo '</td>';
                            echo '</tr>';
                        }
                        echo '</table>';
                    } else {
                        // No restaurants found
                        echo "No restaurants found.";
                    }

                    // Close the database connection
                    $conn->close();
                    ?>

                    <script>
                    function confirmDelete() {
                        return confirm('Are you sure you want to delete this restaurant?');
                    }
                    </script>


                </div>
            </div>
            <!-- users -->
            <div class="tab_content"id="usersContent">
                <div class="top_bar">
                    <div class="bar_name">
                            Users
                    </div>
                </div>
                <div class="users_area">
                <?php
                // Include the database connection file
                include('db_connection.php');

                // Check if the form is submitted
                if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_user'])) {
                    $user_id = $_POST['delete_user'];
                    // Prepare SQL statement to delete user
                    $sql = "DELETE FROM users WHERE id = ?";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("i", $user_id);
                    // Execute the statement
                    if ($stmt->execute()) {
                        // User deleted successfully
                        echo '<div class="success_message">User deleted successfully.</div>';
                    } else {
                        // Error occurred while deleting user
                        echo '<div class="error_message">Error: Unable to delete user. Please try again.</div>';
                    }
                }

                // Prepare SQL statement to retrieve user details excluding password
                $sql = "SELECT id, first_name, last_name, username, email, telephone, address FROM users";
                $result = $conn->query($sql);

                // Check if there are any rows returned
                if ($result->num_rows > 0) {
                    // Output table header
                    echo '<table border="1">';
                    echo '<tr><th>ID</th><th>First Name</th><th>Last Name</th><th>Username</th><th>Email</th><th>Telephone</th><th>Address</th><th>Action</th></tr>';

                    // Output data of each row
                    while ($row = $result->fetch_assoc()) {
                        echo '<tr>';
                        echo '<td>' . $row['id'] . '</td>';
                        echo '<td>' . $row['first_name'] . '</td>';
                        echo '<td>' . $row['last_name'] . '</td>';
                        echo '<td>' . $row['username'] . '</td>';
                        echo '<td>' . $row['email'] . '</td>';
                        echo '<td>' . $row['telephone'] . '</td>';
                        echo '<td>' . $row['address'] . '</td>';
                        // Add a delete button with confirmation
                        echo '<td><form method="post" onsubmit="return confirmDelete()"><button type="submit" name="delete_user" value="' . $row['id'] . '"><i class="fa fa-trash"></i></button></form></td>';
                        echo '</tr>';
                    }
                    echo '</table>';
                } else {
                    // No users found
                    echo "No users found.";
                }

                // Close the database connection
                $conn->close();
                ?>

                <script>
                function confirmDelete() {
                    return confirm("Are you sure you want to delete this user?");
                }
                </script>

                </div>
            </div>
            <!-- messages tab -->
            <div class="tab_content" id="messagesContent">
                <div class="top_bar">
                <div class="bar_name">
                        messages
                    </div>
                </div>
                <div class="users_area">
                <?php
            // Include the database connection file
            include('db_connection.php');

            // Check if the form is submitted
            if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_mail'])) {
                $mail_id = $_POST['delete_mail'];
                // Prepare SQL statement to delete mail
                $sql = "DELETE FROM mails WHERE id = ?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("i", $mail_id);
                // Execute the statement
                if ($stmt->execute()) {
                    // Mail deleted successfully
                    echo '<div class="success_message">Mail deleted successfully.</div>';
                } else {
                    // Error occurred while deleting mail
                    echo '<div class="error_message">Error: Unable to delete mail. Please try again.</div>';
                }
            }

            // Prepare SQL statement to retrieve mail details
            $sql = "SELECT id, email, message, created_at FROM mails";
            $result = $conn->query($sql);

            // Check if there are any rows returned
            if ($result->num_rows > 0) {
                // Output table header
                echo '<table border="1">';
                echo '<tr><th>ID</th><th>Email</th><th>Message</th><th>Created At</th><th>Action</th></tr>';

                // Output data of each row
                while ($row = $result->fetch_assoc()) {
                    echo '<tr>';
                    echo '<td>' . $row['id'] . '</td>';
                    echo '<td>' . $row['email'] . '</td>';
                    echo '<td>' . $row['message'] . '</td>';
                    echo '<td>' . $row['created_at'] . '</td>';
                    // Add a delete button with confirmation
                    echo '<td><form method="post" onsubmit="return confirmDelete()"><button type="submit" name="delete_mail" value="' . $row['id'] . '"><i class="fa fa-trash"></i></button></form></td>';
                    echo '</tr>';
                }
                echo '</table>';
            } else {
                // No mails found
                echo "No mails found.";
            }

            // Close the database connection
            $conn->close();
            ?>

            <!-- avvs -->
         

<script>
function confirmDelete() {
    return confirm("Are you sure you want to delete this mail?");
}
</script>


                </div>
            </div>


            <script>
    document.getElementById('downloadBtn').addEventListener('click', function() {
        // Create a new workbook
        var wb = XLSX.utils.book_new();

        // Define data for the worksheet
        var wsData = [
            ["Restaurants", <?php echo $restaurant_count; ?>],
            ["Users", <?php echo $user_count; ?>],
            ["Messages", <?php echo $mail_count; ?>],
            ["Revenue", <?php echo $total_sum; ?>],
            ["Expenses", <?php echo $total_salary; ?>],
            ["Profit", <?php echo $remaining_balance; ?>]
        ];

        // Create a worksheet and add data to it
        var ws = XLSX.utils.aoa_to_sheet(wsData);

        // Add the worksheet to the workbook
        XLSX.utils.book_append_sheet(wb, ws, "Data");

        // Generate the Excel file and trigger the download
        XLSX.writeFile(wb, "data.xlsx");
    });
</script>

</body>
</html>

<script>
    function openTab(tabId) {
        // Remove the 'active' class from all tab contents
        document.querySelectorAll('.tab_content').forEach(function(tabContent) {
            tabContent.classList.remove('active');
        });

        // Add the 'active' class to the corresponding tab content
        document.getElementById(tabId + 'Content').classList.add('active');
    }
</script>


