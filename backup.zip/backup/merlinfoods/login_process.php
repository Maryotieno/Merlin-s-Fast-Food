<?php
session_start();

include("db_connection.php");

$response = ['type' => 'error', 'message' => 'Invalid request']; // Default response

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = mysqli_real_escape_string($conn, $_POST["email"]);
    $password = $_POST["password"];

    $checkQuery = "SELECT * FROM `users` WHERE `email` = ?";
    $stmt = mysqli_prepare($conn, $checkQuery);
    mysqli_stmt_bind_param($stmt, "s", $email);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if (mysqli_num_rows($result) > 0) {
        $user = mysqli_fetch_assoc($result);

        if (password_verify($password, $user['password'])) {
            // Set email as a session variable upon successful login
            $_SESSION['email'] = $email;

            // Set session variable with login response message
            $_SESSION['login_response'] = ['type' => 'success', 'message' => 'Login successful'];

            // Redirect to index.php upon successful login
            header("Location: index.php");
            exit();
        } else {
            $_SESSION['login_response'] = ['type' => 'error', 'message' => 'Incorrect password'];
        }
    } else {
        $_SESSION['login_response'] = ['type' => 'error', 'message' => 'Email not found'];
    }
}

// If the code reaches this point, it means the login was not successful
// Redirect back to the login page
header("Location: login_page.php");
exit();
?>
