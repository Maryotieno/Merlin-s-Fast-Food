<?php
include "db_connection.php";

// Check if the cartID is received
if (isset($_POST['cartID'])) {
    // Sanitize the input
    $cartID = mysqli_real_escape_string($conn, $_POST['cartID']);

    // Prepare and execute the SQL query to delete the cart item
    $sql = "DELETE FROM `cart` WHERE `cartID` = '$cartID'";
    $result = $conn->query($sql);

    // Check if deletion was successful
    if ($result) {
        // Return a success message if needed
        echo "Item deleted successfully.";
    } else {
        // Return an error message if needed
        echo "Error deleting item: " . $conn->error;
    }
} else {
    // Return an error message if cartID is not received
    echo "Error: Cart ID not received.";
}
?>
