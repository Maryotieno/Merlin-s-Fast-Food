<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transaction</title>
</head>
<body>
    <?php
    include "base.php"
    ?>
    <div class="main_bar">
    <div class="tab_content active" id="transactionsContent">
                <div class="top_bar">
                <div class="bar_name">
                        transactions
                    </div>
                </div>
                <div class="transactions">
                <?php
                    include('db_connection.php');

                    // Prepare SQL statement to retrieve transaction details
                    $sql = "SELECT * FROM transactions";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        // Output table header
                        echo '<table border="1">';
                        echo '<tr><th>Transaction ID</th><th>Email</th><th>Restaurant Name</th><th>Transaction Date</th><th>Items Purchased</th><th>Total Amount</th><th>Payment Method</th><th>Transaction Status</th></tr>';

                        // Output data of each row
                        while ($row = $result->fetch_assoc()) {
                            echo '<tr>';
                            echo '<td>' . $row['transaction_id'] . '</td>';
                            echo '<td>' . $row['email'] . '</td>';
                            echo '<td>' . $row['restaurant_name'] . '</td>';
                            echo '<td>' . $row['transaction_date'] . '</td>';
                            echo '<td>' . $row['items_purchased'] . '</td>';
                            echo '<td>' . $row['total_amount'] . '</td>';
                            echo '<td>' . $row['payment_method'] . '</td>';
                            echo '<td>' . $row['transaction_status'] . '</td>';
                            echo '</tr>';
                        }
                        echo '</table>';
                    } else {
                        // No transactions found
                        echo "No transactions found.";
                    }

                    // Close the database connection
                    $conn->close();
                    ?>

                </div>

                </div>

    </div>
</body>
</html>