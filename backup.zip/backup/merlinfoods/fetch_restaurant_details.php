<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Food Details</title>
    <link rel="stylesheet" href="image.css"> <!-- Replace 'image.css' with the actual CSS file path -->
    <link rel="stylesheet" href="static/index.css"> <!-- Replace 'static/index.css' with the actual CSS file path -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"> <!-- Font Awesome link -->
</head>
<body>
<?php
session_start(); // Start the session
?>

<!-- Your HTML code for the form page -->
<div class="feedback_container">
    <?php
    // Display feedback message if set in session
    if (isset($_SESSION['feedback'])) {
        echo $_SESSION['feedback'];
        unset($_SESSION['feedback']); // Clear the feedback session variable
    }
    ?>
</div>

<?php
include('db_connection.php');

if (isset($_GET['restaurant_name'])) {
    $selectedRestaurantName = $_GET['restaurant_name'];

    // SELECT query to get the restaurant details
    $restaurant_query = "SELECT * FROM restaurants WHERE restaurant_name = '$selectedRestaurantName'";
    $result_restaurant = $conn->query($restaurant_query);

    if ($result_restaurant->num_rows > 0) {
        $row_restaurant = $result_restaurant->fetch_assoc();

        // SELECT query to get all food details for the selected restaurant
        $food_query = "SELECT * FROM foods WHERE restaurant_name = '$selectedRestaurantName'";
        $result_food = $conn->query($food_query);

        if ($result_food === false) {
            // Print the SQL query for debugging purposes
            echo "Error executing food query: " . $conn->error;
        } else {
            echo '<div class="foods_cards_content">';
            echo '<div class="view_food_card">';

            if ($result_food->num_rows > 0) {
                while ($row_food = $result_food->fetch_assoc()) {
                    // Display food items
                    echo '<div class="food_card">';
                    echo '    <div class="food_card_image">';
                    echo '        <img src="' . $row_food['food_image'] . '" alt="" width="100%" height="100%">';
                    echo '    </div>';
                    echo '    <div class="food_card_description">';
                    echo '        <div>';
                    echo '            <div class="food_card_name">';
                    echo '                ' . $row_food['food_name'];
                    echo '                <div class="food_restaurant">' . $row_food['restaurant_name'] . '</div>';
                    echo '            </div>';
                    echo '        </div>';
                    echo '        <div class="food_card_price">' . $row_food['price'] . '</div>';
                    echo '    </div>';
                    echo '    <div class="card_order">';
                    echo '        <div class="buy">Buy now</div>';
                    echo '        <i class="fa fa-shopping-cart" id="shop" onclick="showDetails(this, \'' . $row_food['food_name'] . '\', \'' . $row_food['restaurant_name'] . '\', \'' . $row_food['food_image'] . '\', \'' . $row_food['price'] . '\', \'' . $row_food['food_id'] . '\')"></i>';
                    echo '    </div>';
                    echo '</div>';
                }
            } else {
                echo "No food details found for the restaurant.";
            }

            echo '</div>'; // Close view_food_card
            echo '</div>'; // Close foods_cards_content

            // Display message form (positioned absolutely)
            
            echo <<<HTML
            
            <div class="message_form_container" id="formc">
                <h2>Send a Message to $selectedRestaurantName</h2>
                <div class="message_form">
                    <form action="send_message.php" method="post">
                        <input type="hidden" name="restaurant_name" value="$selectedRestaurantName">
                        <input type="email" id="sender_email" name="sender_email" placeholder="Enter your email" required>
                        <textarea id="message" name="message" placeholder="Enter your message" required></textarea>
                        <button type="submit">Send Message</button>
                    </form>
                </div> <!-- Close message_form -->
            </div> <!-- Close message_form_container -->
     
            HTML;

        }
    } else {
        echo "Restaurant not found.";
    }
} else {
    echo "Invalid request.";
}

$conn->close();
?>
<div class="message_icon" onclick="openForm()"><i class="fa fa-envelope"></i></div>


</body>
</html>
<script>
    function openForm() {
        console.log('Function called');
        document.getElementById('formc').style.display = 'none'
    }
</script>


