<?php
session_start(); // Start session

if (!isset($_SESSION['restaurant_name'])) {
    // Redirect to the registration page if the user is not registered
    header("Location: register.html");
    exit();
}

include('db_connection.php');

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $food_menu = $_POST['food_menu'];
    $food_name = $_POST['food_name'];
    $price = $_POST['price'];
    $restaurant_name = $_SESSION['restaurant_name'];

    // Handle food image upload
    $target_dir = "uploads/";  // Create a directory named 'uploads' in the same directory as your PHP scripts
    $target_file = $target_dir . basename($_FILES["food_image"]["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

    // Check if the file is an actual image
    if(isset($_POST["submit"])) {
        $check = getimagesize($_FILES["food_image"]["tmp_name"]);
        if($check !== false) {
            $_SESSION['success'] = "File is an image - " . $check["mime"] . ".";
            $uploadOk = 1;
        } else {
            $_SESSION['error'] = "File is not an image.";
            $uploadOk = 0;
        }
    }

    // Check if the file already exists
    if (file_exists($target_file)) {
        $_SESSION['error'] = "Sorry, file already exists.";
        $uploadOk = 0;
    }

    // Allow certain file formats
    if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif") {
        $_SESSION['error'] = "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
        $uploadOk = 0;
    }

    // Check if $uploadOk is set to 0 by an error
    if ($uploadOk == 0) {
        $_SESSION['error'] = "Sorry, your file was not uploaded.";
    // If everything is ok, try to upload the file
    } else {
        if (move_uploaded_file($_FILES["food_image"]["tmp_name"], $target_file)) {
            $_SESSION['success'] = "The food image ". htmlspecialchars( basename( $_FILES["food_image"]["name"])). " has been uploaded.";
        } else {
            $_SESSION['error'] = "Sorry, there was an error uploading your file.";
        }
    }

    // Insert data into foods table
    $food_image = $target_file;  // Save the uploaded file path
    $food_insert_query = "INSERT INTO foods (food_image, food_name, restaurant_name, price) VALUES ('$food_image', '$food_name', '$restaurant_name', '$price')";

    if ($conn->query($food_insert_query) === TRUE) {
        $_SESSION['success'] = "Food details added successfully.";
    } else {
        $_SESSION['error'] = "Error: " . $food_insert_query . "<br>" . $conn->error;
    }

    // Redirect back to the page with the appropriate message
    header("Location: {$_SERVER['HTTP_REFERER']}");
    exit();
}

$conn->close();
?>
