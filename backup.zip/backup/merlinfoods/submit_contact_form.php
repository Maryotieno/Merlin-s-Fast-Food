<?php
session_start();
header('Content-Type: application/json');

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate email and message inputs
    $email = $_POST['email'] ?? '';
    $message = $_POST['message'] ?? '';

    // Check if email and message are not empty
    if (!empty($email) && !empty($message)) {
        // Include your database connection file
        include 'db_connection.php';

        // Escape special characters to prevent SQL injection
        $email = mysqli_real_escape_string($conn, $email);
        $message = mysqli_real_escape_string($conn, $message);

        // Insert the submitted data into the database
        $sql = "INSERT INTO mails (email, message) VALUES ('$email', '$message')";

        if (mysqli_query($conn, $sql)) {
            // If insertion is successful, return success message
            echo json_encode(array('success' => true, 'message' => 'Message submitted successfully.'));
        } else {
            // If insertion fails, return error message
            echo json_encode(array('success' => false, 'message' => 'Error: ' . $sql . '<br>' . mysqli_error($conn)));
        }

        // Close the database connection
        mysqli_close($conn);
    } else {
        // If email or message is empty, return error message
        echo json_encode(array('success' => false, 'message' => 'Email and message are required fields.'));
    }
} else {
    // Return error message if accessed directly
    echo json_encode(array('success' => false, 'message' => 'Direct access not allowed.'));
}
?>
