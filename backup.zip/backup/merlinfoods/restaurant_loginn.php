<!-- login.html -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Restaurant </title>
    <link rel="stylesheet" href="static/index.css">
</head>
<body>
    <div class="login_page">
        <form action="restaurant_login.php" method="post" class="owner_logins">
            <h2>view restaurants</h2>
            <br>
            <input type="text" id="restaurant_name" placeholder="restaurant name" name="restaurant_name" required><br><br>
            <input type="hidden" id="password" name="password" value="0000"><br><br>
            <input type="submit" value="view" style="padding:15px 86px;background-color:green;color:white;"><br><br>
            Add a new restaurant <a href="restaurant_form.php">Add</a>
            <?php
            // Check if success message is present in URL
            if(isset($_GET['success'])) {
                $successMessage = $_GET['success'];
                echo "<p style='color:green;'>$successMessage</p>";
            }
            // Check if error message is present in URL
            if(isset($_GET['error'])) {
                $errorMessage = $_GET['error'];
                echo "<p style='color:red;'>$errorMessage</p>";
            }
            ?>
        </form>
    </div>
</body>
</html>