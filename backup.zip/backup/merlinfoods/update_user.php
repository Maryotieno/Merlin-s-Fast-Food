<?php
session_start(); // Start session

include "db_connection.php";

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $id = $_POST['id'];
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $telephone = $_POST['telephone'];
    $address = $_POST['address'];
    $password = $_POST['password'];
    
    // Update user details in the database
    $sql = "UPDATE users SET first_name=?, last_name=?, username=?, email=?, telephone=?, address=?, password=? WHERE id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssssi", $first_name, $last_name, $username, $email, $telephone, $address, $password, $id);
    
    if ($stmt->execute()) {
        // Set success message in session
        $_SESSION['success'] = "User details updated successfully.";
    } else {
        // Set error message in session
        $_SESSION['error'] = "Error updating user details: " . $conn->error;
    }
}

// Close connection
$conn->close();

// Redirect back to index.php
header("Location: index.php");
exit();
?>
