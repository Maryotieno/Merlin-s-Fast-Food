-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 05, 2024 at 04:55 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `merlin_foods_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `username` varchar(50) NOT NULL,
  `password` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`username`, `password`) VALUES
('admin', '0000');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `cartID` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `itemName` varchar(255) NOT NULL,
  `itemRestaurant` varchar(255) NOT NULL,
  `itemPrice` float NOT NULL,
  `amount` int(11) NOT NULL,
  `date` timestamp(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6),
  `status` enum('delivered','pending','dispatched','cancelled') DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`cartID`, `email`, `itemName`, `itemRestaurant`, `itemPrice`, `amount`, `date`, `status`) VALUES
(120, 'bush@gmail.com', 'water', 'Ricky', 250, 2, '2024-03-20 06:01:50.489962', 'cancelled'),
(121, 'caroline@gmail.com', 'kfc', 'ashleys', 450, 2, '2024-03-23 17:25:27.215061', 'pending'),
(123, 'erickmwangi370@gmail.com', 'pilau', 'cabanas', 800, 1, '2024-03-31 07:11:37.728244', 'dispatched'),
(124, 'erickmwangi370@gmail.com', 'chips', 'yummy chicken', 240, 1, '2024-03-24 17:42:45.476900', 'pending'),
(125, 'stacy@gmail.com', 'coca cola', 'cabanas', 150, 2, '2024-03-31 07:10:29.230325', 'dispatched'),
(126, 'stacy@gmail.com', 'coca cola', 'cabanas', 150, 0, '2024-03-25 08:27:12.676001', 'pending'),
(127, 'stacy@gmail.com', 'coca cola', 'cabanas', 150, 1, '2024-03-25 08:27:42.995517', 'pending'),
(128, 'stacy@gmail.com', 'coca cola', 'cabanas', 150, 1, '2024-03-25 08:28:13.694340', 'pending'),
(129, 'stacy@gmail.com', 'coca cola', 'cabanas', 150, 1, '2024-03-31 07:11:42.846549', 'delivered'),
(130, 'stacy@gmail.com', 'coca cola', 'cabanas', 150, 1, '2024-03-25 08:32:20.734926', 'pending'),
(131, 'stacy@gmail.com', 'coca cola', 'cabanas', 150, 1, '2024-03-25 08:40:00.762500', 'pending'),
(132, 'stacy@gmail.com', 'chips', 'nectar', 650, 1, '2024-03-25 08:42:27.325802', 'pending'),
(133, 'stacy@gmail.com', 'chips', 'nectar', 650, 1, '2024-03-25 08:45:41.712558', 'pending'),
(134, 'stacy@gmail.com', 'coca cola', 'cabanas', 150, 1, '2024-03-25 08:48:26.596962', 'pending'),
(135, 'stacy@gmail.com', 'coca cola', 'cabanas', 150, 1, '2024-03-25 08:53:37.681480', 'pending'),
(136, 'stacy@gmail.com', 'chips', 'nectar', 650, 0, '2024-03-25 09:57:41.530330', 'pending'),
(137, 'stacy@gmail.com', 'chips', 'nectar', 650, 0, '2024-03-25 09:58:51.111199', 'pending'),
(138, 'stacy@gmail.com', 'coca cola', 'cabanas', 150, 1, '2024-03-25 09:58:51.151034', 'pending'),
(139, 'stacy@gmail.com', 'coca cola', 'cabanas', 150, 2, '2024-03-25 16:12:19.170460', 'pending'),
(140, 'stac@gmail.com', 'chips', 'cabanas', 56, 1, '2024-03-30 12:36:18.723737', 'pending'),
(141, 'coi@gmail.com', 'chips', 'yummy chicken', 240, 2, '2024-03-30 13:01:24.026766', 'pending'),
(142, 'stacy@gmail.com', 'kfc', 'ashleys', 450, 1, '2024-03-31 09:13:58.801203', 'pending'),
(143, 'stacy@gmail.com', 'COC', 'cabanas', 150, 1, '2024-03-31 09:14:56.780716', 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `foods`
--

CREATE TABLE `foods` (
  `food_id` int(11) NOT NULL,
  `food_image` varchar(255) NOT NULL,
  `food_name` varchar(100) NOT NULL,
  `restaurant_name` varchar(100) DEFAULT NULL,
  `price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `foods`
--

INSERT INTO `foods` (`food_id`, `food_image`, `food_name`, `restaurant_name`, `price`) VALUES
(11, 'uploads/tabimage.png', 'ace', 'cabana', 0.10),
(18, 'uploads/chipo.png', 'chips', 'yummy chicken', 240.00),
(23, 'uploads/coca.png', 'COC', 'cabanas', 150.00),
(24, 'images/nectarchipo.png', 'chips', 'nectar', 650.00),
(25, 'uploads/pilau.png', 'pilau', 'cabanas', 800.00),
(26, 'uploads/lemonade.png', 'lemonade', 'yummy chicken', 1000.00),
(27, 'uploads/kfc.png', 'kfc', 'ashleys', 450.00),
(28, 'uploads/kfc.png', 'kfc', 'ashleys', 450.00),
(32, 'uploads/crown2.png', 'hot dog', 'cabanas', 4.00),
(34, 'uploads/crown4.png', 'hot you', 'cabanas', 200.00);

-- --------------------------------------------------------

--
-- Table structure for table `mails`
--

CREATE TABLE `mails` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mails`
--

INSERT INTO `mails` (`id`, `email`, `message`, `created_at`) VALUES
(11, 'stacy@gmail.com', 'hey\r\n', '2024-03-20 05:39:16');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `message_id` int(11) NOT NULL,
  `restaurant_name` varchar(255) NOT NULL,
  `sender_email` varchar(255) DEFAULT NULL,
  `message_content` text DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`message_id`, `restaurant_name`, `sender_email`, `message_content`, `timestamp`) VALUES
(2, 'aced', 'erickmw@gmail.com', 'hey', '2024-03-13 05:07:08'),
(10, 'ashleys', 'ngeezy@gmail.com', 'everything is fucking amzong', '2024-03-13 07:33:54'),
(17, 'yummy chicken', 'mary@gmail.com', 'yummy yummy yummy', '2024-03-13 09:26:03'),
(18, 'yummy chicken', 'mary@gmail.com', 'yummy yummy yummy', '2024-03-13 09:26:06'),
(19, 'yummy chicken', 'mary@gmail.com', 'yummy yummy yummy', '2024-03-13 09:26:07'),
(20, 'yummy chicken', 'mary@gmail.com', 'yummy yummy yummy', '2024-03-13 09:26:08'),
(21, 'yummy chicken', 'mary@gmail.com', 'yummy yummy yummy', '2024-03-13 09:26:09'),
(22, 'yummy chicken', 'mary@gmail.com', 'yummy yummy yummy', '2024-03-13 09:26:09'),
(23, 'yummy chicken', 'mary@gmail.com', 'yummy yummy yummy', '2024-03-13 09:26:10'),
(24, 'yummy chicken', 'mary@gmail.com', 'yummy yummy yummy', '2024-03-13 09:26:11'),
(27, 'cabana', 'ngeezy@gmail.com', 'hy', '2024-03-19 18:01:26'),
(28, 'cabana', 'mary@gmail.com', 'hey', '2024-03-19 18:08:17'),
(29, 'cabana', 'ngeezy@gmail.com', 'grt', '2024-03-19 18:09:14');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `restaurants`
--

CREATE TABLE `restaurants` (
  `restaurant_name` varchar(100) NOT NULL,
  `restaurant_image` varchar(255) NOT NULL,
  `food_description` varchar(255) NOT NULL,
  `food_menu` enum('breakfast','lunch','dinner','snack','drinks') NOT NULL,
  `food_name` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone_number` varchar(20) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL
) ;

--
-- Dumping data for table `restaurants`
--

INSERT INTO `restaurants` (`restaurant_name`, `restaurant_image`, `food_description`, `food_menu`, `food_name`, `password`, `phone_number`, `email`, `address`) VALUES
('ashleys', 'restaurants/imagesashley.png', 'very waseome the best of best and has fast delivery with top tier foods', 'breakfast', '', '$2y$10$uMqekzh0WftQJIf/XX6VauZ1Hp2A4s1Pb9ij0MxEAEya97H0eZpOe', '98', 'ashlys@gmail.com', 'kagawa'),
('cabana', 'images/res.png', 'dfgh', 'breakfast', '', '$2y$10$lFqO2Nv8W1FxohgcRrc5tuG2OaHO5DhOzHr5N/DkVN5KPhw/CARb6', '56', 'grooveygamers@gmail.com', 'nai'),
('cabanas', 'images/res2.png', 'awesome crazy', 'breakfast', '', '$2y$10$iRw4gKZ54YSkLIzjCwUL1O5vne.W9ZzCE2xJ.2oV/wY3YLBsQgRSu', '56789', 'stacy@gmail.com', 'nairobi'),
('nectar', 'images/nectarres.png', 'awesome taste of pure greatness', 'breakfast', '', '$2y$10$StpThqnPU7Cir58anTR1fu8vIxpej7YYxSv2oY7L.orW3P31gEVFK', '797431552', 'stacy@gmail.com', 'bamburi,mombasa'),
('yummy chicken', 'restaurants/images/tabimage.png', 'yummy yummy', 'breakfast', '', '$2y$10$LJOaxQpK/vWPJXwbplqN7eF5yxBJwCQXjTovz2bTcPRpCOvQmJ6.m', '0115456527', 'yummy@gmail.com', 'avenue , thika');

-- --------------------------------------------------------

--
-- Table structure for table `staffs`
--

CREATE TABLE `staffs` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `role` varchar(50) NOT NULL,
  `salary` int(50) NOT NULL,
  `join_date` date NOT NULL,
  `restaurant_name` varchar(255) DEFAULT NULL,
  `phone_number` varchar(20) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `staffs`
--

INSERT INTO `staffs` (`id`, `name`, `email`, `role`, `salary`, `join_date`, `restaurant_name`, `phone_number`, `address`, `password`) VALUES
(14, 'Maina erick Mwangi ', 'stacy@gmail.com', 'driver', 45000, '0000-00-00', 'cabanas', '0716663356', 'thika', '$2y$10$qWmKmAiR5FaP4k8WdmHb/ehhsveY0G.f1LES3WBitTBvcWYi9fPGS');

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `transaction_id` int(11) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `restaurant_name` int(11) DEFAULT NULL,
  `transaction_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `items_purchased` text DEFAULT NULL,
  `total_amount` decimal(10,2) DEFAULT NULL,
  `payment_method` varchar(50) DEFAULT NULL,
  `transaction_status` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`transaction_id`, `email`, `restaurant_name`, `transaction_date`, `items_purchased`, `total_amount`, `payment_method`, `transaction_status`) VALUES
(1, 'john@gmail.com', 0, '2024-03-31 21:00:00', 'Pizza, Salad', 30000.00, 'mpesa', 'Completed'),
(2, 'emma@gmail.com', 0, '2024-03-31 21:00:00', 'Burger, Fries, Soda', 80000.00, 'mpesa', 'completed');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `telephone` int(14) NOT NULL,
  `address` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `username`, `email`, `telephone`, `address`, `password`) VALUES
(12, 'erick', 'maina', 'ace', 'stacy@gmail.com', 790077009, 'thika', '$2y$10$NRX/zTc4CJsaHmny02VYz.UQx4GFR5VIPyLc5JIO2tdRugDobqWDS'),
(13, 'alex', 'maina', 'aced', 'erickmwangi370@gmail.com', 900, 'thika, mukiriti', '$2y$10$NRX/zTc4CJsaHmny02VYz.UQx4GFR5VIPyLc5JIO2tdRugDobqWDS'),
(16, 'mary', 'atieno', 'monsorrate', 'mary@gmail.com', 116112224, '', '$2y$10$dTsNFf/S.aW8lRGhp4NDquVjdjfRxDfnLpePiflcnlryok/9C7Cs2'),
(17, 'vin', 'alex', 'vinny', '78@gmail.com', 45678, '', '$2y$10$U4KEEiB.l0I0epy5t3WR0.l6rTfBqGIkBX38jYcyNWLFApwc9rh9C'),
(18, 'JAMES', 'NGANGA', 'BUSH', 'bush@gmail.com', 716451551, 'thika', '$2y$10$48NSpLSd7MRhwAaMhj9J8uTlNCpiDA1ZgzlE/rS3hE83GYNmLLN4e'),
(19, 'ojuka', 'clifford', 'ojuka', 'cliff@gmail.com', 708081885, '', '$2y$10$7BSikRR7SGueEuFBUlTq9efofxve8GgUoE6vzZneK3uhDwYM0WCBK'),
(20, 'Hope', 'Wanjiku', 'Hopie', 'hopenjoroge302@gmail.com', 741040517, '', '$2y$10$TvsyrM99ZbVJp1Otpm0ikO99WajXLBLuifPaRXLhAddG9XMwO5lLm'),
(21, 'julius ', 'wairimu', 'wyre', 'julius@gmail.com', 115456527, '', '$2y$10$JIeg55ZYvlxdDYwCzblxTeX/eYV1EO71wE3pelfvdPpAaa0kUg0vi'),
(22, 'john', 'maina', 'johnte', 'johni@gmail.com', 116112224, '', '$2y$10$t5wtjGRs7mKjYOUYPKSxIO4YfsnNytboUitCAdDAtAokT78b9wwIy');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`cartID`);

--
-- Indexes for table `foods`
--
ALTER TABLE `foods`
  ADD PRIMARY KEY (`food_id`),
  ADD KEY `fk_restaurant_name` (`restaurant_name`);

--
-- Indexes for table `mails`
--
ALTER TABLE `mails`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`message_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `restaurants`
--
ALTER TABLE `restaurants`
  ADD PRIMARY KEY (`restaurant_name`);

--
-- Indexes for table `staffs`
--
ALTER TABLE `staffs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `fk_restaurant_name_staffs` (`restaurant_name`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`transaction_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `cartID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=144;

--
-- AUTO_INCREMENT for table `foods`
--
ALTER TABLE `foods`
  MODIFY `food_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `mails`
--
ALTER TABLE `mails`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `message_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `staffs`
--
ALTER TABLE `staffs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `transaction_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1004;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `foods`
--
ALTER TABLE `foods`
  ADD CONSTRAINT `fk_restaurant_name` FOREIGN KEY (`restaurant_name`) REFERENCES `restaurants` (`restaurant_name`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_restaurant_name_foods` FOREIGN KEY (`restaurant_name`) REFERENCES `restaurants` (`restaurant_name`) ON DELETE CASCADE;

--
-- Constraints for table `staffs`
--
ALTER TABLE `staffs`
  ADD CONSTRAINT `fk_restaurant_name_staffs` FOREIGN KEY (`restaurant_name`) REFERENCES `restaurants` (`restaurant_name`) ON DELETE CASCADE,
  ADD CONSTRAINT `staffs_ibfk_1` FOREIGN KEY (`restaurant_name`) REFERENCES `restaurants` (`restaurant_name`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
