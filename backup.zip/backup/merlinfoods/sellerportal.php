<?php
session_start();


// Check if user is logged in
if (!isset($_SESSION['restaurant_name'])) {
    header("Location: restaurant_loginn.php");
    exit(); // Ensure script execution stops after redirection
}

?>
<?php

include('db_connection.php');

// Get the logged-in restaurant name
$restaurant_name = $_SESSION['restaurant_name'];

// Define the directory to save the CSV file
$directory = 'reports/';
// Ensure the directory exists or create it
if (!is_dir($directory)) {
    mkdir($directory, 0755, true);
}

// Define the file path
$filepath = $directory . 'report.csv';

// Create a file pointer
$fp = fopen($filepath, 'w');

if ($fp === false) {
    echo "Failed to open the file.";
    exit;
}

// Query to retrieve data from cart and users tables
$sql = "SELECT c.cartID, c.email AS cart_email, c.itemName, c.itemPrice, c.amount, c.date, c.status, u.telephone, u.address, u.id AS user_id
        FROM cart AS c
        INNER JOIN users AS u ON c.email = u.email
        WHERE c.itemRestaurant = '$restaurant_name'";

$result = $conn->query($sql);

// Check if there are any results
if ($result->num_rows > 0) {
    // Output CSV header
    fputcsv($fp, array('User ID', 'User Telephone', 'User Address', 'Food ID', 'Food Name', 'Amount', 'Price', 'Date', 'Status'));

    // Output data of each row
    while ($row = $result->fetch_assoc()) {
        // Access data using associative array keys
        $cartID = $row['cartID'];
        $cart_email = $row['cart_email'];
        $itemName = $row['itemName'];
        $itemPrice = $row['itemPrice'];
        $amount = $row['amount'];
        $date = $row['date'];
        $status = $row['status'];
        $telephone = $row['telephone'];
        $address = $row['address'];
        $user_id = $row['user_id'];

        // Write row to CSV file
        fputcsv($fp, array($user_id, $telephone, $address, $cartID, $itemName, $amount, $itemPrice, $date, $status));
    }
}

// Close the file pointer
fclose($fp);

// Close the database connection
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="static/admin.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.7.0/chart.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
    <div class="admin_page">
        <div class="side_bar">
        <?php

            include('db_connection.php');

            $restaurant_name = $_SESSION['restaurant_name'];

            // Retrieve data from the database
            $query = "SELECT * FROM restaurants WHERE restaurant_name = '$restaurant_name'";
            $result = $conn->query($query);

            if ($result->num_rows > 0) {
                // Fetch the first row
                $row = $result->fetch_assoc();

                // Assign rows to variables
                $restaurantName = $row["restaurant_name"];
                $foodDescription = $row["food_description"];
                $phoneNumber = $row["phone_number"];
                $email = $row["email"];
                $address = $row["address"];
                $restaurantimage = $row["restaurant_image"];
                // You can assign other fields as needed

                // Output the variables
                // echo "Food Description: $foodDescription <br>";
                // echo "Phone Number: $phoneNumber <br>";
                // echo "Email: $email <br>";
                // echo "Address: $address <br>";
                // You can output other variables as needed
            } else {
                echo "No data found for this restaurant.";
            }

            $conn->close();
            ?>

            <div class="company_name">MERLIN FOOD <br> <p>DELIVERY</p></div>
            <div class="myrestaurant" style="background-image: url(<?php echo $restaurantimage; ?>);background-size: cover; background-position: center; background-repeat: no-repeat; width: 80%; height: 25%;margin-left:10%;border-radius:10px;">
            <div class="restaurant_name"><?php echo $restaurantName; ?></div>
            </div>
            <ul>
                <li onclick="openTab('dashboard')"><div class="lists"><i class="fa fa-dashboard"></i> Dashboard</div></li>
                <li onclick="openTab('foods')"><div class="lists"><i class="fa fa-cutlery"></i> Foods</div></li>
                <li onclick="openTab('orders')"> <div class="lists"><i class="fa fa-shopping-cart"></i> Orders</div></li>
                <li onclick="openTab('transactions')"><div class="lists"><i class="fa fa-exchange"></i> Transactions</div></li>
                <li onclick="openTab('staffs')"><div class="lists"><i class="fa fa-user-circle"></i> Staffs</div></li>
                <li onclick="openTab('messages')"><div class="lists"><i class="fa fa-envelope"></i> Messages</div></li>
            </ul>


            <hr>
            <div class="side_bar_address">
                <div class="side_bar_email"> <i class="fa fa-map-marker"></i><?php echo $address; ?></div>
                <div class="side_bar_email"><?php echo $email; ?></div>
                <div class="admin_logout"><a href="restaurant_logout.php">Logout</a></div>

            </div>
            
        </div>
        <div class="main_bar">

            <!-- dashboard -->

            <div class="tab_content active " id="dashboardContent">
                <div class="top_bar">
                    <div class="bar_name">
                        Dashboard
                    </div>
                </div> 
               <div class="dashboard_boxes">
               <?php

                // Check if the restaurant name is set in the session
                if(isset($_SESSION['restaurant_name'])) {
                    // Get the restaurant name from the session
                    $restaurantName = $_SESSION['restaurant_name'];

                    try {
                        // Include the file containing the database connection logic
                        include 'db_connection.php';

                        // Connect to the database
                        $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
                        // Set the PDO error mode to exception
                        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                        // Prepare the SQL statement to count total rows
                        $sql_total = "SELECT COUNT(*) AS total_count FROM `cart` WHERE `itemRestaurant` = :restaurant_name";
                        
                        // Prepare the SQL statement to count rows for different statuses
                        $sql_delivered = "SELECT COUNT(*) AS delivered_count FROM `cart` WHERE `itemRestaurant` = :restaurant_name AND `status` = 'delivered'";
                        $sql_cancelled = "SELECT COUNT(*) AS cancelled_count FROM `cart` WHERE `itemRestaurant` = :restaurant_name AND `status` = 'cancelled'";
                        $sql_pending = "SELECT COUNT(*) AS pending_count FROM `cart` WHERE `itemRestaurant` = :restaurant_name AND `status` = 'pending'";

                        // Prepare and execute the query to count total rows
                        $stmt_total = $conn->prepare($sql_total);
                        $stmt_total->bindParam(':restaurant_name', $restaurantName);
                        $stmt_total->execute();
                        $result_total = $stmt_total->fetch(PDO::FETCH_ASSOC);

                        // Prepare and execute the queries for different statuses
                        $stmt_delivered = $conn->prepare($sql_delivered);
                        $stmt_delivered->bindParam(':restaurant_name', $restaurantName);
                        $stmt_delivered->execute();
                        $result_delivered = $stmt_delivered->fetch(PDO::FETCH_ASSOC);

                        $stmt_cancelled = $conn->prepare($sql_cancelled);
                        $stmt_cancelled->bindParam(':restaurant_name', $restaurantName);
                        $stmt_cancelled->execute();
                        $result_cancelled = $stmt_cancelled->fetch(PDO::FETCH_ASSOC);

                        $stmt_pending = $conn->prepare($sql_pending);
                        $stmt_pending->bindParam(':restaurant_name', $restaurantName);
                        $stmt_pending->execute();
                        $result_pending = $stmt_pending->fetch(PDO::FETCH_ASSOC);

                        $sql_total_foods = "SELECT COUNT(*) AS total_count FROM `foods` WHERE `restaurant_name` = :restaurant_name";
                        
                        $stmt_total_foods = $conn->prepare($sql_total_foods);
                        $stmt_total_foods->bindParam(':restaurant_name', $restaurantName);
                        $stmt_total_foods->execute();
                        $result_total_foods = $stmt_total_foods->fetch(PDO::FETCH_ASSOC);

                       
                    } catch(PDOException $e) {
                        // Handle database connection errors
                        echo "Error: " . $e->getMessage();
                    }

                    // Close the database connection
                    $conn = null;
                } else {
                    echo "Restaurant name not set in session.";
                }
                ?>
                <div class="boxes">Total Foods <br><?php echo $result_total_foods['total_count']; ?></div>
                <div class="boxes">Orders <br><?php echo $result_total['total_count']; ?></div>
                <div class="boxes">Rejected <br><?php echo $result_cancelled['cancelled_count']; ?></div>
                <div class="boxes">Pending <br><?php echo $result_pending['pending_count']; ?></div>
                <div class="boxes">Delivered <br><?php echo $result_delivered['delivered_count']; ?></div>

               </div> 
               <div class="bottom">
               <div class="aob">
                      <ul class="order_header">
                        <li><div class="head">Food name</div></li>
                        <li><div class="head">Amount</div></li>
                        <li><div class="head">delivery</div></li>
                        <li><div class="head">Date</div></li>
                        <li><div class="head">Action</div></li>
                      </ul>  
                      <?php
                include('db_connection.php');

                // Get the logged-in restaurant name
                $restaurant_name = $_SESSION['restaurant_name'];

                // Query to retrieve data from cart and users tables
                $sql = "SELECT c.cartID, c.email AS cart_email, c.itemName, c.itemPrice, c.amount, c.date, c.status, u.telephone, u.address, u.id AS user_id
                        FROM cart AS c
                        INNER JOIN users AS u ON c.email = u.email
                        WHERE c.itemRestaurant = '$restaurant_name'";

                $result = $conn->query($sql);

                // Check if there are any results
                if ($result->num_rows > 0) {
                    // Output data of each row
                    while ($row = $result->fetch_assoc()) {
                        // Access data using associative array keys
                        $cartID = $row['cartID'];
                        $cart_email = $row['cart_email'];
                        $itemName = $row['itemName'];
                        $itemPrice = $row['itemPrice'];
                        $amount = $row['amount'];
                        $date = $row['date'];
                        $status = $row['status'];
                        $telephone = $row['telephone'];
                        $address = $row['address'];
                        $user_id = $row['user_id'];
                        ?>
                   

                      <ul class="order_details">
                        <li><div class="details"><?php echo $itemName; ?></div></li>
                        <li><div class="details"><?php echo $amount; ?></div></li>
                        <li><div class="details"><?php echo $address; ?></div></li>
                        <li><div class="details"><?php echo $date; ?></div></li>
                        <li><div class="details" style="padding:5px 2px;color:white; width:60px;margin-left:25px;background-color:var(--sec);">Open</div></li>
                      </ul>  
                      <?php
                    }
                    } else {
                        echo "No results found.";
                    }

                    // Close the database connection
                    $conn->close();
                    ?>
                </div>
                <div class="graph">
                <canvas id="orderChart" width="400" height="250"style="margin-top:15px;margin-left:20px;" >
                </canvas>
                <script>
    var ctx = document.getElementById('orderChart').getContext('2d');
    var orderChart = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: ['Delivered', 'Cancelled', 'Pending'],
            datasets: [{
                label: 'Orders',
                data: [
                    <?php echo $result_delivered['delivered_count']; ?>,
                    <?php echo $result_cancelled['cancelled_count']; ?>,
                    <?php echo $result_pending['pending_count']; ?>
                ],
                backgroundColor: [
                    'rgba(54, 162, 235, 0.5)',
                    'rgba(255, 99, 132, 0.5)',
                    'rgba(255, 206, 86, 0.5)'
                ],
                borderColor: [
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 99, 132, 1)',
                    'rgba(255, 206, 86, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: false, // Prevents resizing of the chart
            plugins: {
                legend: {
                    position: 'right' // Adjust legend position
                },
                title: {
                    display: true,
                    text: 'Order Status'
                }
            }
        }
    });
                </script>
                </div>
               </div>
            </div>

            <!-- foods tab -->
            <div class="tab_content" id="foodsContent">
                <div class="top_bar">
                    <div class="bar_name">
                        Foods
                    </div>
                </div>
                <div class="foods_header">
                    <ul>
                        <li>Food Image</li>
                        <li>Food ID</li>
                        <li>Food Name</li>
                        <li>Food Price</li>
                        <li>Actions</li>
                    </ul>
                </div>
                <div class="foods_display">
                    <?php
                    include('db_connection.php');

                    // Get the logged-in restaurant name
                    $restaurant_name = $_SESSION['restaurant_name'];

                    // Query to retrieve food_id, food_image, food_name, and price for the logged-in restaurant
                    $sql = "SELECT food_id, food_image, food_name, price FROM foods WHERE restaurant_name = '$restaurant_name'";
                    $result = $conn->query($sql);

                    // Check if there are any results
                    if ($result->num_rows > 0) {
                        // Output data of each row
                        while ($row = $result->fetch_assoc()) {
                            // Access data using associative array keys
                            $food_id = $row['food_id'];
                            $food_image = $row['food_image'];
                            $food_name = $row['food_name'];
                            $price = $row['price'];
                    ?>
                    <ul>
                        <li><img src="<?php echo $food_image; ?>" alt="" width="80px" height="100%" style="border-radius: 8px;"></li>
                        <li><?php echo $food_id; ?></li>
                        <li><?php echo $food_name; ?></li>
                        <li>Kshs <?php echo $price; ?></li>
                        <li style="display: flex; gap:16px;">
                            <i class="fa fa-pencil" onclick="toggleForm(<?php echo $food_id; ?>)"></i>
                            <i class="fa fa-trash" onclick="deleteFood(<?php echo $food_id; ?>)"></i>
                        </li>
                    </ul>
            <!-- Update Form for Food -->
            <form id="updateForm_<?php echo $food_id; ?>" class="update-form" style="display: none;" action="update_food.php" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="food_id" value="<?php echo $food_id; ?>">
                <div class="form-group">
                    <label for="food_name">Food Name:</label>
                    <input type="text" id="food_name" name="food_name" value="<?php echo $food_name; ?>" required>
                </div>
                <div class="form-group">
                    <label for="food_image">Food Image:</label><br>
                    <img src="<?php echo $food_image; ?>" alt="Previous Image" width="100"><br>
                    <input type="file" id="food_image" name="food_image">
                </div>

                <div class="form-group">
                    <label for="price">Price:</label>
                    <input type="number" id="price" name="price" value="<?php echo $price; ?>" required><br>
                </div>
                <button type="submit">Update Food</button>
                <!-- Success/Error messages -->
                <?php
                if(isset($_GET['success'])) {
                    $successMessage = $_GET['success'];
                    echo "<p class='success-message'>$successMessage</p>";
                }
                if(isset($_GET['error'])) {
                    $errorMessage = $_GET['error'];
                    echo "<p class='error-message'>$errorMessage</p>";
                }
                ?>
            </form>
                    <?php
                        }
                    } else {
                        echo "No results found.";
                    }

                    // Close the database connection
                    $conn->close();
                    ?>
                </div>

                <!-- Add FOODS -->
                <div class="add_foods" id="add_foods">
                    <form action="insert_data.php" method="post" enctype="multipart/form-data">
                        <!-- Form fields for adding new food items -->
                    </form>
                </div>
            </div>

            <script>
                function toggleForm(foodId) {
                    var form = document.getElementById("updateForm_" + foodId);
                    if (form.style.display === "none") {
                        form.style.display = "block";
                    } else {
                        form.style.display = "none";
                    }
                }
            </script>

            <!-- orders tab -->

            <div class="tab_content  " id="ordersContent">
                <div class="top_bar">
                <div class="bar_name">
                        Orders
                    </div>
                </div> 

                <div class="foods_display">

    
    <table>
        <thead>
            <tr>
                <th>User ID</th>
                <th>User Telephone</th>
                <th>User Address</th>
                <th>Food ID</th>
                <th>Food Name</th>
                <th>Amount</th>
                <th>Price</th>
                <th>Date</th>
                <th>Status</th>
                
                <th> <a href="<?php echo $filepath; ?>" download="report.csv"><button>Download Report</button></a></th>
            </tr>
        </thead>
        <tbody>
            <?php
            include('db_connection.php');

            // Get the logged-in restaurant name
            $restaurant_name = $_SESSION['restaurant_name'];

            // Query to retrieve data from cart and users tables
            $sql = "SELECT c.cartID, c.email AS cart_email, c.itemName, c.itemPrice, c.amount, c.date, c.status, u.telephone, u.address, u.id AS user_id
                    FROM cart AS c
                    INNER JOIN users AS u ON c.email = u.email
                    WHERE c.itemRestaurant = '$restaurant_name'";

            $result = $conn->query($sql);

            // Check if there are any results
            if ($result->num_rows > 0) {
                // Output data of each row
                while ($row = $result->fetch_assoc()) {
                    // Access data using associative array keys
                    $cartID = $row['cartID'];
                    $cart_email = $row['cart_email'];
                    $itemName = $row['itemName'];
                    $itemPrice = $row['itemPrice'];
                    $amount = $row['amount'];
                    $date = $row['date'];
                    $status = $row['status'];
                    $telephone = $row['telephone'];
                    $address = $row['address'];
                    $user_id = $row['user_id'];
                    ?>
                    <tr>
                        <td><?php echo $user_id; ?></td>
                        <td><?php echo $telephone; ?></td>
                        <td><?php echo $address; ?></td>
                        <td><?php echo $cartID; ?></td>
                        <td><?php echo $itemName; ?></td>
                        <td><?php echo $amount; ?></td>
                        <td><?php echo $itemPrice; ?></td>
                        <td><?php echo $date; ?></td>
                        <td>
                            <form action="update_status.php" method="post">
                                <input type="hidden" name="cartID" value="<?php echo $cartID; ?>">
                                <select name="status">
                                    <option value="pending" <?php echo ($status == 'pending') ? 'selected' : ''; ?>>Pending</option>
                                    <option value="dispatched" <?php echo ($status == 'dispatched') ? 'selected' : ''; ?>>Dispatched</option>
                                    <option value="delivered" <?php echo ($status == 'delivered') ? 'selected' : ''; ?>>Delivered</option>
                                    <option value="cancelled" <?php echo ($status == 'cancelled') ? 'selected' : ''; ?>>Cancelled</option>
                                </select>
                                <button type="submit">Update</button>
                            </form>
                        </td>
                    </tr>
                    <?php
                }
            } else {
                echo "<tr><td colspan='10'>No results found.</td></tr>";
            }

            // Close the database connection
            $conn->close();
            ?>
        </tbody>
    </table>
</div>
            
            </div>

            <!-- messages tab -->

            <div class="tab_content active" id="messagesContent">
                <div class="top_bar">
                <div class="bar_name">
                        messages
                    </div>
                </div>
                <div class="messages_area">
                <?php
                    include 'db_connection.php';
                    if(isset($_SESSION['restaurant_name'])) {
                        $restaurantName = $_SESSION['restaurant_name'];
                        try {
                            $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
                            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                            $sql = "SELECT `message_id`, `restaurant_name`, `sender_email`, `message_content`, `timestamp` FROM `messages` WHERE `restaurant_name` = :restaurant_name";
                            $stmt = $conn->prepare($sql);
                            $stmt->bindParam(':restaurant_name', $restaurantName);
                            $stmt->execute();
                            $messages = $stmt->fetchAll(PDO::FETCH_ASSOC);
                        } catch(PDOException $e) {
                            echo "Error: " . $e->getMessage();
                        }
                        $conn = null;
                    } else {
                        echo "Restaurant name not set in session.";
                    }
                    ?>

                    <?php if (!empty($messages)): ?>
                        <?php foreach ($messages as $message): ?>
                            <div class="messages_containers">
                                <div style="padding:3px;height:15%;">
                                    <div style="display:flex;gap :10px;">
                                        <p style="color:brown;">From </p><p><?php echo $message['sender_email']; ?></p>
                                    </div>
                                    <p  style="color:brown;"><?php echo $message['timestamp']; ?></p>
                                </div>
                                <div class="message">
                                    <?php echo $message['message_content']; ?>
                                </div>
                                <div class="message_footer">
                                    <a href="delete_message.php?message_id=<?php echo $message['message_id']; ?>">Delete message</a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="no_messages">
                            No messages for you.
                        </div>
                    <?php endif; ?>

                    <?php
                    // Display success message if set
                    if(isset($_SESSION['success_message'])) {
                        echo '<div class="success_message">' . $_SESSION['success_message'] . '</div>';
                        // Unset the session variable to remove the message after displaying
                        unset($_SESSION['success_message']);
                    }

                    // Display error message if set
                    if(isset($_SESSION['error_message'])) {
                        echo '<div class="error_message">' . $_SESSION['error_message'] . '</div>';
                        // Unset the session variable to remove the message after displaying
                        unset($_SESSION['error_message']);
                    }
                    ?>

                </div>
            </div>
                <!-- dtaffs -->
            <div class="tab_content active " id="staffsContent">
                <div class="top_bar">
                    <div class="bar_name">
                            Staffs
                    </div>
                </div>
                <div class="staffs_space">
                <?php
                    include('db_connection.php');

                    // Check if the restaurant_name is set
                    if (isset($_SESSION['restaurant_name'])) {
                        $restaurant_name = $_SESSION['restaurant_name'];

                        // Prepare SQL statement to retrieve staff details
                        $sql = "SELECT * FROM staffs WHERE restaurant_name = ?";
                        $stmt = $conn->prepare($sql);

                        // Check if the statement was prepared successfully
                        if ($stmt) {
                            // Bind the restaurant_name parameter to the prepared statement
                            $stmt->bind_param("s", $restaurant_name);

                            // Execute the statement
                            if ($stmt->execute()) {
                                // Get the result set
                                $result = $stmt->get_result();

                                // Check if there are any rows returned
                                if ($result->num_rows > 0) {
                                    // Display staff details in a table
                                    echo '<table border="1">';
                                    echo '<tr><th>Name</th><th>Email</th><th>Role</th><th>Phone Number</th><th>Address</th><th>Action</th></tr>';
                                    while ($row = $result->fetch_assoc()) {
                                        echo '<tr>';
                                        echo '<td>' . $row['name'] . '</td>';
                                        echo '<td>' . $row['email'] . '</td>';
                                        echo '<td>' . $row['role'] . '</td>';
                                        echo '<td>' . $row['phone_number'] . '</td>';
                                        echo '<td>' . $row['address'] . '</td>';
                                        echo '<td>';
                                        // Delete button with confirmation dialog
                                        echo '<a href="delete_staff.php?id=' . $row['id'] . '" onclick="return confirm(\'Are you sure you want to delete this staff member?\');"><i class="fa fa-trash"></i></a>';
                                        // Update button
                                        echo '&nbsp;<a href="update_staff.php?id=' . $row['id'] . '"><i class="fa fa-pencil"></i></a>';
                                        echo '</td>';
                                        echo '</tr>';
                                    }
                                    echo '</table>';
                                } else {
                                    // No staff found for the restaurant
                                    echo "No staff found for the restaurant.";
                                }
                            } else {
                                // Error executing the statement
                                echo "Error: Unable to execute statement.";
                            }
                        } else {
                            // Error preparing the statement
                            echo "Error: Unable to prepare statement.";
                        }
                    } else {
                        // Restaurant name not set in session
                        echo "Restaurant name not set in session.";
                    }

                    // Close the database connection
                    $conn->close();
                    ?>
                <script>
                    function confirmDelete(staffId) {
                        if (confirm("Are you sure you want to delete this staff member?")) {
                            window.location.href = "delete_staff.php?id=" + staffId;
                        }
                    }
                </script>


                </div>
                <div class="add_staff">
                <form action="add_staff.php" method="post">
                    <label for="name">Name:</label><br>
                    <input type="text" id="name" name="name" required><br>
                    
                    <label for="email">Email:</label><br>
                    <input type="email" id="email" name="email" required><br>
                                        
                    <label for="role">Role:</label><br>
                    <input type="text" id="role" name="role" required><br>
                    
                    <!-- Populate the restaurant name from the session -->
                    <input type="hidden" id="restaurant_name" name="restaurant_name" value="<?php echo $_SESSION['restaurant_name']; ?>">
                    <label for="phone_number">Phone Number:</label><br>
                    <input type="tel" id="phone_number" name="phone_number"><br>
                    
                    <label for="address">Address:</label><br>
                    <textarea id="address" name="address"></textarea><br>
                    
                    <input type="submit" value="Add Staff">
                </div>
            </div>

            <!-- Content for transactions tab -->

            <div class="tab_content " id="transactionsContent">
                <div class="top_bar">
                <div class="bar_name">
                        transactions
                    </div>
                </div>
                <div class="transactions">
                <?php
                    include('db_connection.php');

                    // Prepare SQL statement to retrieve transaction details
                    $sql = "SELECT * FROM transactions";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        // Output table header
                        echo '<table border="1">';
                        echo '<tr><th>Transaction ID</th><th>Email</th><th>Restaurant Name</th><th>Transaction Date</th><th>Items Purchased</th><th>Total Amount</th><th>Payment Method</th><th>Transaction Status</th></tr>';

                        // Output data of each row
                        while ($row = $result->fetch_assoc()) {
                            echo '<tr>';
                            echo '<td>' . $row['transaction_id'] . '</td>';
                            echo '<td>' . $row['email'] . '</td>';
                            echo '<td>' . $row['restaurant_name'] . '</td>';
                            echo '<td>' . $row['transaction_date'] . '</td>';
                            echo '<td>' . $row['items_purchased'] . '</td>';
                            echo '<td>' . $row['total_amount'] . '</td>';
                            echo '<td>' . $row['payment_method'] . '</td>';
                            echo '<td>' . $row['transaction_status'] . '</td>';
                            echo '</tr>';
                        }
                        echo '</table>';
                    } else {
                        // No transactions found
                        echo "No transactions found.";
                    }

                    // Close the database connection
                    $conn->close();
                    ?>

                </div>

                </div>


    <div class="add_new_foods"><i class="fa fa-plus" onclick="openPlus()"></i></div>
</body>
</html>

