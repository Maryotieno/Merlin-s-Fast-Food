<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="static/index.css">
</head>
<body>
    <div class="login_page">
        <form method="post" action="staff_login.php" class="owner_logins">
        <h2 style="margin-bottom:10px;">Staff Login</h2>
        <input type="email" id="email" name="email" required placeholder="enter email"><br><br>
        <input type="password" id="password" name="password" required placeholder="password"><br><br>
        
        <button type="submit" name="login" style="padding:10px 88px;color:white;background-color:green; ">Login</button>
    </form>
    </div>
</body>
</html>
