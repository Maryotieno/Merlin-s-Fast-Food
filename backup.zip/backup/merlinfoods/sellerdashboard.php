<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
</head>
<body>
    <?php
    include "base.php"
    ?>
    <div class="main_bar">
    <div class="tab_content active " id="dashboardContent">
                <div class="top_bar">
                    <div class="bar_name">
                        Dashboard
                    </div>
                </div> 
               <div class="dashboard_boxes">
               <?php

                // Check if the restaurant name is set in the session
                if(isset($_SESSION['restaurant_name'])) {
                    // Get the restaurant name from the session
                    $restaurantName = $_SESSION['restaurant_name'];

                    try {
                        // Include the file containing the database connection logic
                        include 'db_connection.php';

                        // Connect to the database
                        $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
                        // Set the PDO error mode to exception
                        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                        // Prepare the SQL statement to count total rows
                        $sql_total = "SELECT COUNT(*) AS total_count FROM `cart` WHERE `itemRestaurant` = :restaurant_name";
                        
                        // Prepare the SQL statement to count rows for different statuses
                        $sql_delivered = "SELECT COUNT(*) AS delivered_count FROM `cart` WHERE `itemRestaurant` = :restaurant_name AND `status` = 'delivered'";
                        $sql_cancelled = "SELECT COUNT(*) AS cancelled_count FROM `cart` WHERE `itemRestaurant` = :restaurant_name AND `status` = 'cancelled'";
                        $sql_pending = "SELECT COUNT(*) AS pending_count FROM `cart` WHERE `itemRestaurant` = :restaurant_name AND `status` = 'pending'";

                        // Prepare and execute the query to count total rows
                        $stmt_total = $conn->prepare($sql_total);
                        $stmt_total->bindParam(':restaurant_name', $restaurantName);
                        $stmt_total->execute();
                        $result_total = $stmt_total->fetch(PDO::FETCH_ASSOC);

                        // Prepare and execute the queries for different statuses
                        $stmt_delivered = $conn->prepare($sql_delivered);
                        $stmt_delivered->bindParam(':restaurant_name', $restaurantName);
                        $stmt_delivered->execute();
                        $result_delivered = $stmt_delivered->fetch(PDO::FETCH_ASSOC);

                        $stmt_cancelled = $conn->prepare($sql_cancelled);
                        $stmt_cancelled->bindParam(':restaurant_name', $restaurantName);
                        $stmt_cancelled->execute();
                        $result_cancelled = $stmt_cancelled->fetch(PDO::FETCH_ASSOC);

                        $stmt_pending = $conn->prepare($sql_pending);
                        $stmt_pending->bindParam(':restaurant_name', $restaurantName);
                        $stmt_pending->execute();
                        $result_pending = $stmt_pending->fetch(PDO::FETCH_ASSOC);

                        $sql_total_foods = "SELECT COUNT(*) AS total_count FROM `foods` WHERE `restaurant_name` = :restaurant_name";
                        
                        $stmt_total_foods = $conn->prepare($sql_total_foods);
                        $stmt_total_foods->bindParam(':restaurant_name', $restaurantName);
                        $stmt_total_foods->execute();
                        $result_total_foods = $stmt_total_foods->fetch(PDO::FETCH_ASSOC);

                       
                    } catch(PDOException $e) {
                        // Handle database connection errors
                        echo "Error: " . $e->getMessage();
                    }

                    // Close the database connection
                    $conn = null;
                } else {
                    echo "Restaurant name not set in session.";
                }
                ?>
                <div class="boxes">Total Foods <br><?php echo $result_total_foods['total_count']; ?></div>
                <div class="boxes">Orders <br><?php echo $result_total['total_count']; ?></div>
                <div class="boxes">Rejected <br><?php echo $result_cancelled['cancelled_count']; ?></div>
                <div class="boxes">Pending <br><?php echo $result_pending['pending_count']; ?></div>
                <div class="boxes">Delivered <br><?php echo $result_delivered['delivered_count']; ?></div>

               </div> 
               <div class="bottom">
               <div class="aob">
                      <ul class="order_header">
                        <li><div class="head">Food name</div></li>
                        <li><div class="head">Amount</div></li>
                        <li><div class="head">delivery</div></li>
                        <li><div class="head">Date</div></li>
                        <li><div class="head">Action</div></li>
                      </ul>  
                      <?php
                include('db_connection.php');

                // Get the logged-in restaurant name
                $restaurant_name = $_SESSION['restaurant_name'];

                // Query to retrieve data from cart and users tables
                $sql = "SELECT c.cartID, c.email AS cart_email, c.itemName, c.itemPrice, c.amount, c.date, c.status, u.telephone, u.address, u.id AS user_id
                        FROM cart AS c
                        INNER JOIN users AS u ON c.email = u.email
                        WHERE c.itemRestaurant = '$restaurant_name'";

                $result = $conn->query($sql);

                // Check if there are any results
                if ($result->num_rows > 0) {
                    // Output data of each row
                    while ($row = $result->fetch_assoc()) {
                        // Access data using associative array keys
                        $cartID = $row['cartID'];
                        $cart_email = $row['cart_email'];
                        $itemName = $row['itemName'];
                        $itemPrice = $row['itemPrice'];
                        $amount = $row['amount'];
                        $date = $row['date'];
                        $status = $row['status'];
                        $telephone = $row['telephone'];
                        $address = $row['address'];
                        $user_id = $row['user_id'];
                        ?>
                   

                      <ul class="order_details">
                        <li><div class="details"><?php echo $itemName; ?></div></li>
                        <li><div class="details"><?php echo $amount; ?></div></li>
                        <li><div class="details"><?php echo $address; ?></div></li>
                        <li><div class="details"><?php echo $date; ?></div></li>
                        <li><div class="details" style="padding:5px 2px;color:white; width:60px;margin-left:25px;background-color:var(--sec);"><a href="sellerorders.php">open</a></div></li>
                      </ul>  
                      <?php
                    }
                    } else {
                        echo "No results found.";
                    }

                    // Close the database connection
                    $conn->close();
                    ?>
                </div>
                <div class="graph">
                <canvas id="orderChart" width="400" height="250"style="margin-top:15px;margin-left:20px;" >
                </canvas>
                <script>
    var ctx = document.getElementById('orderChart').getContext('2d');
    var orderChart = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: ['Delivered', 'Cancelled', 'Pending'],
            datasets: [{
                label: 'Orders',
                data: [
                    <?php echo $result_delivered['delivered_count']; ?>,
                    <?php echo $result_cancelled['cancelled_count']; ?>,
                    <?php echo $result_pending['pending_count']; ?>
                ],
                backgroundColor: [
                    'rgba(54, 162, 235, 0.5)',
                    'rgba(255, 99, 132, 0.5)',
                    'rgba(255, 206, 86, 0.5)'
                ],
                borderColor: [
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 99, 132, 1)',
                    'rgba(255, 206, 86, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: false, // Prevents resizing of the chart
            plugins: {
                legend: {
                    position: 'right' // Adjust legend position
                },
                title: {
                    display: true,
                    text: 'Order Status'
                }
            }
        }
    });
                </script>
                </div>
               </div>
            </div>

    </div>
</body>
</html>