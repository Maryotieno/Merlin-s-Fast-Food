<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="static/index.css">
    <script src="static/script.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    
</head>
<body>
<div id="foods-content" class="content">
            <div class="foods_cards_content">
                <div class="view_food_card">

                    <?php
                    include('db_connection.php');

                    $foods_query = "SELECT * FROM foods";
                    $result_foods = $conn->query($foods_query);
                    

                    if ($result_foods->num_rows > 0) {
                        while ($row = $result_foods->fetch_assoc()) {
                            // Open the food card container for each row
                            ?>
                            
                            <div class="food_card">
                                <div class="food_card_image">
                                    <img src="<?php echo $row['food_image']; ?>" alt="" width="100%" height="100%">
                                </div>
                                <div class="food_card_description">
                                    <div>
                                        <div class="food_card_name">
                                            <?php echo $row['food_name']; ?>
                                            <div class="food_restaurant"><?php echo $row['restaurant_name']; ?></div>
                                        </div>
                                    </div>
                                    <div class="food_card_price"><?php echo $row['price']; ?></div>
                                </div>

                                <!-- Display order button -->
                                <div class="card_order">
                                    <div class="buy"  id="shop" onclick="showDetails(this, '<?php echo $row['food_name']; ?>', '<?php echo $row['restaurant_name']; ?>', '<?php echo $row['food_image']; ?>', '<?php echo $row['price']; ?>', ' <?php echo $row['food_id'] ?>')">Buy now</div>
                                    <i class="fa fa-shopping-cart" id="shop" onclick="showDetails(this, '<?php echo $row['food_name']; ?>', '<?php echo $row['restaurant_name']; ?>', '<?php echo $row['food_image']; ?>', '<?php echo $row['price']; ?>', ' <?php echo $row['food_id'] ?>')"></i>
                                </div>
                            </div>
                            <?php
                        }
                    } else {
                        echo "No foods found.";
                    }
                    ?>
                </div>
                <script>
                function searchFoods() {
                        var input, filter, cards, card, foodName, i, txtValue;
                        input = document.getElementById("food_search");
                        filter = input.value.toUpperCase();
                        cards = document.getElementsByClassName("food_card");

                        for (i = 0; i < cards.length; i++) {
                            card = cards[i];
                            foodName = card.getElementsByClassName("food_card_name")[0];
                            txtValue = foodName.textContent || foodName.innerText;
                            if (txtValue.toUpperCase().indexOf(filter) > -1) {
                                card.style.display = "";
                            } else {
                                card.style.display = "none";
                            }
                        }
                    }
                </script>
            </div>
        </div>
</body>
</html>