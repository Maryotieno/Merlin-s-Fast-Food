<?php
// Include database connection
include('db_connection.php');

// Check if form is submitted with data
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve staff details from the form
    $id = $_POST['id'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $role = $_POST['role'];
    $phone_number = $_POST['phone_number'];
    $address = $_POST['address'];

    // SQL query to update staff details
    $sql = "UPDATE staffs SET name=?, email=?, role=?, phone_number=?, address=? WHERE id=?";
    $stmt = $conn->prepare($sql);

    if ($stmt) {
        // Bind parameters
        $stmt->bind_param("sssssi", $name, $email, $role, $phone_number, $address, $id);

        // Execute the statement
        if ($stmt->execute()) {
            // Redirect to restaurantstaffs.php with success message
            header("Location: restaurantstaffs.php?success=Staff details updated successfully");
            exit();
        } else {
            // Redirect with error message if execution fails
            header("Location: restaurantstaffs.php?error=Error updating staff details");
            exit();
        }
    } else {
        // Redirect with error message if statement preparation fails
        header("Location: restaurantstaffs.php?error=Error preparing update statement");
        exit();
    }
} else {
    // Redirect if form data is not submitted
    header("Location: restaurantstaffs.php");
    exit();
}

// Close the database connection
// $conn->close();
?>
