<?php
include 'db_connection.php';
session_start(); // Start the session

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $restaurant_name = $_POST['restaurant_name'];
    $restaurant_image = $_POST['restaurant_image'];
    $food_description = $_POST['food_description'];
    $password = $_POST['password']; // Note: You might want to hash the password before storing it in the database
    $phone_number = $_POST['phone_number'];
    $email = $_POST['email'];
    $address = $_POST['address'];

    // Update the restaurant's information in the database
    $sql = "UPDATE restaurants SET 
            restaurant_image = '$restaurant_image',
            food_description = '$food_description',
            password = '$password',
            phone_number = '$phone_number',
            email = '$email',
            address = '$address'
            WHERE restaurant_name = '$restaurant_name'";

    if (mysqli_query($conn, $sql)) {
        // Redirect to the page where you want to show the updated information
        header("Location: sellerportal.php");
        exit();
    } else {
        echo "Error updating record: " . mysqli_error($conn);
    }

    // Close database connection (You might want to keep it open if you're performing other operations)
    mysqli_close($conn);
} else {
    // If the form is not submitted via POST method, redirect to the appropriate page
    header("Location: index.php");
    exit();
}
?>
