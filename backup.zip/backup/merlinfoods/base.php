<?php
session_start();
if (!isset($_SESSION['restaurant_name'])) {
    header("Location: restaurant_loginn.php");
    exit(); 
}
?>
<?php

include('db_connection.php');
$restaurant_name = $_SESSION['restaurant_name'];
$directory = 'reports/';
if (!is_dir($directory)) {
    mkdir($directory, 0755, true);
}
$filepath = $directory . 'report.csv';
$fp = fopen($filepath, 'w');
if ($fp === false) {
    echo "Failed to open the file.";
    exit;
}
$sql = "SELECT c.cartID, c.email AS cart_email, c.itemName, c.itemPrice, c.amount, c.date, c.status, u.telephone, u.address, u.id AS user_id
        FROM cart AS c
        INNER JOIN users AS u ON c.email = u.email
        WHERE c.itemRestaurant = '$restaurant_name'";

$result = $conn->query($sql);
if ($result->num_rows > 0) {
    fputcsv($fp, array('User ID', 'User Telephone', 'User Address', 'Food ID', 'Food Name', 'Amount', 'Price', 'Date', 'Status'));
    while ($row = $result->fetch_assoc()) {
        $cartID = $row['cartID'];
        $cart_email = $row['cart_email'];
        $itemName = $row['itemName'];
        $itemPrice = $row['itemPrice'];
        $amount = $row['amount'];
        $date = $row['date'];
        $status = $row['status'];
        $telephone = $row['telephone'];
        $address = $row['address'];
        $user_id = $row['user_id'];
        fputcsv($fp, array($user_id, $telephone, $address, $cartID, $itemName, $amount, $itemPrice, $date, $status));
    }
}
fclose($fp);
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Seller Portal</title>
    <link rel="stylesheet" href="static/admin.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.7.0/chart.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
    <div class="admin_page">
        <div class="side_bar">
            <?php
                include('db_connection.php');
                $restaurant_name = $_SESSION['restaurant_name'];
                $query = "SELECT * FROM restaurants WHERE restaurant_name = '$restaurant_name'";
                $result = $conn->query($query);
                if ($result->num_rows > 0) {
                    $row = $result->fetch_assoc();
                    $restaurantName = $row["restaurant_name"];
                    $foodDescription = $row["food_description"];
                    $phoneNumber = $row["phone_number"];
                    $email = $row["email"];
                    $address = $row["address"];
                    $restaurantimage = $row["restaurant_image"];
                } else {
                    echo "No data found for this restaurant.";
                }
                $conn->close();
                ?>
                <div class="company_name">MERLIN FOOD <br> <p>DELIVERY</p></div>
                <div class="myrestaurant" style="background-image: url(<?php echo $restaurantimage; ?>);background-size: cover; background-position: center; background-repeat: no-repeat; width: 80%; height: 25%;margin-left:10%;border-radius:10px;">
                <div class="restaurant_name"><?php echo $restaurantName; ?></div>
                </div>
                <ul>
                <li onclick="openTab('dashboard')"><div class="lists"><i class="fa fa-dashboard"></i> <a href="sellerdashboard.php">Dashboard</a></div></li>
                    <li><div class="lists"><i class="fa fa-cutlery"></i> <a href="sellerfoods.php">Foods</a></div></li>
                    <li> <div class="lists"><i class="fa fa-shopping-cart"></i><a href="sellerorders.php">orders</a></div></li>
                    <li><div class="lists"><i class="fa fa-exchange"></i> <a href="sellertransactions.php">Transactions</a></div></li>
                    <li><div class="lists"><i class="fa fa-user-circle"></i> <a href="restaurantstaffs.php">Staffs</a></div></li>
                    <li><div class="lists"><i class="fa fa-envelope"></i> <a href="restaurantmessages.php">Messages</a></div></li>
                </ul>
                <hr>
                <div class="side_bar_address">
                    <div class="side_bar_email"> <i class="fa fa-map-marker"></i><?php echo $address; ?></div>
                    <div class="side_bar_email"><?php echo $email; ?></div>
                    <div class="admin_logout"><a href="restaurant_logout.php">Logout</a></div>

                </div>
                
        </div>
    </div>
</body>
</html>
<script>
    function openTab(tabId) {
        // Remove the 'active' class from all tab contents
        document.querySelectorAll('.tab_content').forEach(function(tabContent) {
            tabContent.classList.remove('active');
        });

        // Add the 'active' class to the corresponding tab content
        document.getElementById(tabId + 'Content').classList.add('active');
    }
</script>


<script>
    function openPlus(){
        const plusWidget = document.getElementById('add_foods');
        if ( plusWidget.style.width <= "0%"){
            plusWidget.style.width = "20%"
        } else {
           plusWidget.style.width = "0%"
        }
    }

 
</script>
<script>
    function deleteFood(foodId) {
        // Ask for confirmation before deleting the food item
        var confirmDelete = confirm("Are you sure you want to delete this food item?");
        if (confirmDelete) {
            // If user confirms, send AJAX request to delete food
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "delete_food.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    // Handle response from PHP script
                    var response = xhr.responseText;
                    if (response === "success") {
                        // Food deleted successfully, update UI as needed
                        location.reload(); // Refresh the page
                    } else {
                        // Failed to delete food, display error message or handle accordingly
                        console.log("Failed to delete food: " + response);
                    }
                }
            };
            xhr.send("food_id=" + foodId);
        } else {
            // If user cancels, do nothing
            console.log("Deletion canceled.");
        }
    }
</script>
<script>
    function deleteMessage(messageId) {
        // Ask for confirmation before deleting the message
        var confirmDelete = confirm("Are you sure you want to delete this message?");
        if (confirmDelete) {
            // If user confirms, send AJAX request to delete message
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "delete_message.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    // Handle response from PHP script
                    var response = xhr.responseText;
                    if (response === "success") {
                        // Message deleted successfully, update UI as needed
                        location.reload(); // Refresh the page
                    } else {
                        // Failed to delete message, display error message or handle accordingly
                        alert("Failed to delete message: " + response);
                    }
                }
            };
            xhr.send("message_id=" + messageId);
        } else {
            // If user cancels, do nothing
            console.log("Deletion canceled.");
        }
    }
</script>
<script>
    function toggleForm(foodId) {
    var form = document.getElementById("updateForm_" + foodId);
    if (form.style.display === "none") {
    form.style.display = "block";
    } else {
    form.style.display = "none";
    }
    }
    </script>
    <script>
    function toggleForm(foodId) {
    var form = document.getElementById("updateForm_" + foodId);
    if (form.style.display === "none") {
    form.style.display = "block";
    } else {
    form.style.display = "none";
    }
    }
    </script>



