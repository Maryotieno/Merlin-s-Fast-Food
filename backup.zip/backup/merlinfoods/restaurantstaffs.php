<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staffs</title>
</head>
<body>
   <?php
    include "base.php"
   ?>
   <div class="main_bar">
   <div class="tab_content active " id="staffsContent">
                <div class="top_bar">
                    <div class="bar_name">
                            Staffs
                    </div>
                </div>
                <div class="staffs_space">
                <?php
include('db_connection.php');

// Check if the restaurant_name is set
if (isset($_SESSION['restaurant_name'])) {
    $restaurant_name = $_SESSION['restaurant_name'];

    // Prepare SQL statement to retrieve staff details
    $sql = "SELECT * FROM staffs WHERE restaurant_name = ?";
    $stmt = $conn->prepare($sql);

    // Check if the statement was prepared successfully
    if ($stmt) {
        // Bind the restaurant_name parameter to the prepared statement
        $stmt->bind_param("s", $restaurant_name);

        // Execute the statement
        if ($stmt->execute()) {
            // Get the result set
            $result = $stmt->get_result();

            // Check if there are any rows returned
            if ($result->num_rows > 0) {
          
if (isset($_GET['success'])) {
    echo "<p style='color:green;'>" . $_GET['success'] . "</p>";
} elseif (isset($_GET['error'])) {
    echo "<p style='color:red;'>" . $_GET['error'] . "</p>";
}

                // Display staff details in a table
                echo '<table border="1">';
                echo '<tr><th>Name</th><th>Email</th><th>Role</th><th>Salary</th><th>Phone Number</th><th>Address</th><th>Action</th></tr>';
                while ($row = $result->fetch_assoc()) {
                    echo '<tr>';
                    echo '<td>' . $row['name'] . '</td>';
                    echo '<td>' . $row['email'] . '</td>';
                    echo '<td>' . $row['role'] . '</td>';
                    echo '<td>' . $row['salary'] . '</td>';
                    echo '<td>' . $row['phone_number'] . '</td>';
                    echo '<td>' . $row['address'] . '</td>';
                    echo '<td>';
                    // Delete button with confirmation dialog
                    echo '<a href="delete_staff.php?id=' . $row['id'] . '" onclick="return confirm(\'Are you sure you want to delete this staff member?\');"><i class="fa fa-trash"></i></a>';
                    // Update button
                    echo '&nbsp;<a href="#" class="update-button" data-staff-id="' . $row['id'] . '"><i class="fa fa-pencil"></i></a>';
                    echo '</td>';
                    echo '</tr>';

                    // Update Form for Staff (Initially hidden)
                    echo '<tr class="update-form" id="update-form-' . $row['id'] . '" style="display: none;">';
                    echo '<td colspan="6">';
                    echo '<form action="update_staff.php?id=' . $row['id'] . '" method="POST">';
                    echo '<label for="name">Name:</label><br>';
                    echo '<input type="text" id="name" name="name" value="' . $row['name'] . '" required><br>';
                    echo '<label for="email">Email:</label><br>';
                    echo '<input type="email" id="email" name="email" value="' . $row['email'] . '" required><br>';
                    echo '<label for="role">Role:</label><br>';
                    echo '<input type="text" id="role" name="role" value="' . $row['role'] . '" required><br>';
                    echo '<label for="salary">salary:</label><br>';
                    echo '<input type="text" id="salary" name="salary" value="' . $row['salary'] . '" required><br>';
                    echo '<label for="phone_number">Phone Number:</label><br>';
                    echo '<input type="tel" id="phone_number" name="phone_number" value="' . $row['phone_number'] . '"><br>';
                    echo '<label for="address">Address:</label><br>';
                    echo '<textarea id="address" name="address">' . $row['address'] . '</textarea><br>';
                    echo '<input type="submit" value="Update Staff">';
                    echo '</form>';
                    echo '</td>';
                    echo '</tr>';
                }
                echo '</table>';
            } else {
                // No staff found for the restaurant
                echo "No staff found for the restaurant.";
            }
        } else {
            // Error executing the statement
            echo "Error: Unable to execute statement.";
        }
    } else {
        // Error preparing the statement
        echo "Error: Unable to prepare statement.";
    }
} else {
    // Restaurant name not set in session
    echo "Restaurant name not set in session.";
}

// Close the database connection
$conn->close();
?>

<script>
    // jQuery code to toggle the update form
    $(document).ready(function() {
        $('.update-button').click(function() {
            var staffId = $(this).data('staff-id');
            $('#update-form-' + staffId).toggle();
        });
    });
</script>

<script>
function confirmDelete(staffId) {
    if (confirm("Are you sure you want to delete this staff member?")) {
        window.location.href = "delete_staff.php?id=" + staffId;
    }
}
</script>


                </div>
                <div class="add_staff">
                <form action="add_staff.php" method="post">
                    <label for="name">Name:</label><br>
                    <input type="text" id="name" name="name" required><br>
                    
                    <label for="email">Email:</label><br>
                    <input type="email" id="email" name="email" required><br>
                                        
                    <label for="role">Role:</label><br>
                    <input type="text" id="role" name="role" required><br>

                    <label for="salary">salary:</label><br>
                    <input type="text" id="salary" name="salary" required><br>
                    
                    <!-- Populate the restaurant name from the session -->
                    <input type="hidden" id="restaurant_name" name="restaurant_name" value="<?php echo $_SESSION['restaurant_name']; ?>">
                    <label for="phone_number">Phone Number:</label><br>
                    <input type="tel" id="phone_number" name="phone_number"><br>
                    
                    <label for="address">Address:</label><br>
                    <textarea id="address" name="address"></textarea><br>

                    <label for="password">password:</label><br>
                    <input type="password" id="password" name="password" required><br>
                    
                    <input type="submit" value="Add Staff">
                </div>
            </div>

   </div>
</body>
</html>