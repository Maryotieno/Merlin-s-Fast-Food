<?php
session_start();

// Check if the login form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['login'])) {
    // Retrieve form data
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Validate the email and password (you may need more sophisticated validation)
    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
        // Hash the password (replace 'your_secret_key' with your actual secret key)
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Here you should query your database to check if the email and hashed password match
        // Example SQL query: SELECT * FROM users WHERE email = ? LIMIT 1
        // Bind parameters and execute the query
        // If a user is found, compare the hashed password with the stored hashed password
        // Example code: if (password_verify($password, $hashed_password_from_database)) { // Login successful }

        // For demonstration purposes, let's assume the login is successful
        // Set a session variable to indicate the user is logged in
        $_SESSION['user_email'] = $email;

        // Redirect to the home page or dashboard after successful login
        header("Location: sellerdashboard.php");
        exit();
    } else {
        // Invalid email format
        $_SESSION['error_message'] = "Invalid email format.";
        header("Location: login.php");
        exit();
    }
} else {
    // Redirect to the login page if the form is not submitted
    header("Location: login.php");
    exit();
}
?>
