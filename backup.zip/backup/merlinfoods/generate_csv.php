<?php
// Include the database connection file
include('db_connection.php');

// Get start and end dates from the query string
$start_date = $_GET['start_date'];
$end_date = $_GET['end_date'];

// Prepare SQL statement to fetch amount and transaction date within the date range
$sql = "SELECT total_amount, transaction_date FROM transactions WHERE transaction_date BETWEEN ? AND ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $start_date, $end_date);
$stmt->execute();
$result = $stmt->get_result();

// Set CSV headers
header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="report.csv"');

// Open output stream
$output = fopen('php://output', 'w');

// Write CSV headers
fputcsv($output, array('Amount', 'Transaction Date'));

// Write data rows
while ($row = $result->fetch_assoc()) {
    fputcsv($output, array($row['total_amount'], $row['transaction_date']));
}

// Close output stream
fclose($output);

// Close database connection
$conn->close();
?>
