<?php
// Include your database connection file
include "db_connection.php";

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if all required fields are present
    if (isset($_POST['food_id']) && isset($_POST['food_name']) && isset($_POST['price'])) {
        // Sanitize inputs to prevent SQL injection
        $food_id = mysqli_real_escape_string($conn, $_POST['food_id']);
        $food_name = mysqli_real_escape_string($conn, $_POST['food_name']);
        $price = mysqli_real_escape_string($conn, $_POST['price']);

        // Check if food image is uploaded
        if (!empty($_FILES['food_image']['name'])) {
            // Process food image upload
            $target_dir = "uploads/";
            $target_file = $target_dir . basename($_FILES["food_image"]["name"]);
            $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

            // Check if the file is an image
            $check = getimagesize($_FILES["food_image"]["tmp_name"]);
            if ($check !== false) {
                // Check if file already exists
                if (file_exists($target_file)) {
                    echo "Sorry, file already exists.";
                } else {
                    // Upload the file
                    if (move_uploaded_file($_FILES["food_image"]["tmp_name"], $target_file)) {
                        // Update food details in the database
                        $sql = "UPDATE foods SET food_name='$food_name', price='$price', food_image='$target_file' WHERE food_id='$food_id'";
                        if ($conn->query($sql) === TRUE) {
                            // Redirect to previous page with success message
                            header("Location: previous_page.php?success=Food updated successfully.");
                            exit();
                        } else {
                            echo "Error updating record: " . $conn->error;
                        }
                    } else {
                        echo "Sorry, there was an error uploading your file.";
                    }
                }
            } else {
                echo "File is not an image.";
            }
        } else {
            // Update food details in the database without changing the image
            $sql = "UPDATE foods SET food_name='$food_name', price='$price' WHERE food_id='$food_id'";
            if ($conn->query($sql) === TRUE) {
                // Redirect to previous page with success message
                header("Location: sellerfoods.php?success=Food updated successfully.");
                exit();
            } else {
                echo "Error updating record: " . $conn->error;
            }
        }
    } else {
        // Handle missing fields error
        echo "All fields are required.";
    }
} else {
    // Redirect to previous page if accessed directly without form submission
    header("Location:sellerfoods.php");
    exit();
}

// Close database connection
$conn->close();
?>
