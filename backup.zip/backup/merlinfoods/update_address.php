<?php
// Start or resume the session
session_start();

// Check if the email is set in the session
if(isset($_SESSION['email'])) {
    // Get the email from the session
    $email = $_SESSION['email'];

    // Check if the new address is set in the POST data
    if(isset($_POST['new_address'])) {
        // Get the new address from the POST data
        $newAddress = $_POST['new_address'];

        try {
            // Include the file containing the database connection logic
            include 'db_connection.php';

            // Connect to the database
            $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
            // Set the PDO error mode to exception
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            // Prepare the SQL statement to update the address
            $sql = "UPDATE `users` SET `address` = :new_address WHERE `email` = :email";

            // Prepare the query
            $stmt = $conn->prepare($sql);
            // Bind parameters
            $stmt->bindParam(':new_address', $newAddress);
            $stmt->bindParam(':email', $email);
            // Execute the query
            $stmt->execute();

            // Redirect back to the page with a success message
            $_SESSION['success_message'] = "Address updated successfully.";
            header("Location: index.php"); // Change "index.php" to the desired page
            exit();
        } catch(PDOException $e) {
            // Handle database connection errors
            $_SESSION['error_message'] = "Error: " . $e->getMessage();
            header("Location: index.php"); // Change "index.php" to the desired page
            exit();
        }

        // Close the database connection
        $conn = null;
    } else {
        $_SESSION['error_message'] = "New address not provided.";
        header("Location: index.php"); // Change "index.php" to the desired page
        exit();
    }
} else {
    $_SESSION['error_message'] = "Email not set in session.";
    header("Location: index.php"); // Change "index.php" to the desired page
    exit();
}
?>
