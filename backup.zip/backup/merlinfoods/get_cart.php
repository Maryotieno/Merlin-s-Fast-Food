<?php
include("db_connection.php");

$query = "SELECT * FROM `cart`";
$data = mysqli_query($conn, $query);

$result = array();

while ($data_item = $data->fetch_assoc()) {
    $result[] = array(
        'itemName' => $data_item['itemName'],
        'itemRestaurant' => $data_item['itemRestaurant'],
        'itemPrice' => $data_item['itemPrice'],
        'itemCount' => $data_item['itemCount']
    );
}

echo json_encode($result);
?>
