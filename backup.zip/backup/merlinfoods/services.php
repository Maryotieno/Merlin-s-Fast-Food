<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Food Ordering Platform</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f8f8f8;
            background-image: url(../images/back.png);
            margin: 0;
            padding: 0;
            color: #333;
            line-height: 1.6;
        }

        .container {
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }

        h1, h2, h3 {
            margin-bottom: 20px;
            color: #333;
        }

        p {
            margin-bottom: 15px;
        }

        .service-sections {
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 20px;
        }

        .service {
            flex: 1 1 30%;
            padding: 20px;
            border-radius: 8px;
            background-color: #f9f9f9;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
        }

        .order-button {
            display: inline-block;
            padding: 10px 20px;
            background-color: #4caf50;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            transition: background-color 0.3s;
        }

        .order-button:hover {
            background-color: #45a049;
        }

        .service h2 {
            font-size: 24px;
            color: #333;
            margin-bottom: 10px;
        }

        .service p {
            font-size: 16px;
            color: #666;
        }
    </style>
</head>
<body>
    <?php include 'hearder.php';?>
    <div class="container">
        <h1>Welcome to Our Food Ordering Platform</h1>
        <div class="service-sections">
            <div class="service">
                <h2>Discover Delicious Foods</h2>
                <p>We offer a diverse range of culinary delights tailored to satisfy every palate. From savory starters to delectable desserts, our platform connects you with a plethora of restaurants and eateries, each offering their unique specialties.</p>
                <a href="#" class="order-button">Order Now</a>
            </div>
            <div class="service">
                <h2>Explore Top Restaurants</h2>
                <p>Welcome to our online food ordering platform, where a world of culinary delights awaits you! Our curated selection of restaurants offers something for every taste and occasion, ensuring a diverse and satisfying dining experience for all.</p>
                <a href="#" class="order-button">Visit Now</a>
            </div>
            <div class="service">
                <h2>Efficient Delivery Services</h2>
                <p>Experience the convenience of browsing through menus, placing orders, and arranging deliveries all from the comfort of your home or office. With seamless integration of payment gateways and real-time order tracking, we prioritize efficiency and reliability.</p>
                <a href="#" class="order-button">Arrange Delivery</a>
            </div>
        </div>
    </div>
</body>
</html>
