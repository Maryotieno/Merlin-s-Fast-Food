<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php include "base.php"; ?>
    <div class="main_bar">
        <div class="tab_content active " id="ordersContent">
            <div class="top_bar">
                <div class="bar_name">
                    Orders
                </div>
            </div> 

            <!-- Date Range Filter -->
            <form action="" method="GET">
                <label for="start_date">Start Date:</label>
                <input type="date" id="start_date" name="start_date">
                <label for="end_date">End Date:</label>
                <input type="date" id="end_date" name="end_date">
                <button type="submit">Filter</button>
                <a href="#" onclick="generate_report()"><i class="fa fa-download"></i></a>
                <input type="text" id="item_id" placeholder="Enter Food">
                <!-- Search Button -->
                <!--  -->
                <button type="button" onclick="searchFood()">Search</button>
            </form>
            <script>
                function generate_report(){
                    url = 'generate_report.php'
                    var start_date = document.getElementById('start_date').value
                    var end_date = document.getElementById('end_date').value
                    window.location.href = url+'?start_date='+start_date+'&end_date='+end_date
                }

                function searchFood() {
                    var foodId = document.getElementById('item_id').value.trim();
                    if (foodId !== '') {
                        window.location.href = 'sellerorders.php?food_id=' + foodId;
                    } else {
                        alert('Please enter a Food ID.');
                    }
                }
            </script>

            <div class="foods_display">
                <table>
                    <thead>
                        <tr>
                            <th>User ID</th>
                            <th>User Telephone</th>
                            <th>User Address</th>
                            <th>Food ID</th>
                            <th>Food Name</th>
                            <th>Times</th>
                            <th>Price</th>
                            <th>Date</th>
                            <th>Status</th>
                            <th>Update Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        include('db_connection.php');

                        // Get the logged-in restaurant name
                        $restaurant_name = $_SESSION['restaurant_name'];

                        // Initialize variables for date range filtering
                        $start_date = $_GET['start_date'] ?? '';
                        $end_date = $_GET['end_date'] ?? '';
                        $food_id = $_GET['food_id'] ?? ''; // Changed from item_id to food_id

                        // Query to retrieve data from cart and users tables with optional date filtering
                        $sql = "SELECT c.cartID, c.email AS cart_email, c.itemName, c.itemPrice, c.amount, c.date, c.status, u.telephone, u.address, u.id AS user_id
                                FROM cart AS c
                                INNER JOIN users AS u ON c.email = u.email
                                WHERE c.itemRestaurant = '$restaurant_name'";

                        // Add date filtering condition if start_date and end_date are provided
                        if ($start_date && $end_date) {
                            $sql .= " AND c.date BETWEEN '$start_date' AND '$end_date'";
                        }

                        // Add food_id filtering condition if food_id is provided
                        if ($food_id) {
                            // $sql .= " AND c.cartID = '$food_id'";
                            $sql .= " AND c.itemName = '$food_id'"; //(Use $foodId here)

                        }

                        $result = $conn->query($sql);

                        // Check if there are any results
                        if ($result->num_rows > 0) {
                            // Output data of each row
                            while ($row = $result->fetch_assoc()) {
                                // Access data using associative array keys
                                $cartID = $row['cartID'];
                                $cart_email = $row['cart_email'];
                                $itemName = $row['itemName'];
                                $itemPrice = $row['itemPrice'];
                                $amount = $row['amount'];
                                $date = $row['date'];
                                $status = $row['status'];
                                $telephone = $row['telephone'];
                                $address = $row['address'];
                                $user_id = $row['user_id'];
                                ?>
                                <tr>
                                    <!-- Display Table Data -->
                                    <td><?php echo $user_id; ?></td>
                                    <td><?php echo $telephone; ?></td>
                                    <td><?php echo $address; ?></td>
                                    <td><?php echo $cartID; ?></td>
                                    <td><?php echo $itemName; ?></td>
                                    <td><?php echo $amount; ?></td>
                                    <td><?php echo $itemPrice; ?></td>
                                    <td><?php echo $date; ?></td>
                                    <td><?php echo $status; ?></td>
                                    <td>
                                        <!-- Update Status Form -->
                                        <form action="update_status.php" method="post">
                                            <input type="hidden" name="cartID" value="<?php echo $cartID; ?>">
                                            <select name="status">
                                                <option value="pending" <?php echo ($status == 'pending') ? 'selected' : ''; ?>>Pending</option>
                                                <option value="dispatched" <?php echo ($status == 'dispatched') ? 'selected' : ''; ?>>Dispatched</option>
                                                <option value="delivered" <?php echo ($status == 'delivered') ? 'selected' : ''; ?>>Delivered</option>
                                                <option value="cancelled" <?php echo ($status == 'cancelled') ? 'selected' : ''; ?>>Cancelled</option>
                                            </select>
                                            <button type="submit">Update</button>
                                        </form>
                                    </td>
                                </tr>
                                <?php
                            }
                        } else {
                            echo "<tr><td colspan='10'>No results found.</td></tr>";
                        }

                        // Close the database connection
                        $conn->close();
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>
