<?php
include('db_connection.php');

// Check if the request method is POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve food ID from POST data
    $food_id = $_POST['food_id'];

    // Delete the food item from the database
    $sql = "DELETE FROM foods WHERE food_id = $food_id";
    if ($conn->query($sql) === TRUE) {
        echo "success"; // Send success response
    } else {
        echo "error: " . $conn->error; // Send error response
    }
}

// Close the database connection
$conn->close();
?>
