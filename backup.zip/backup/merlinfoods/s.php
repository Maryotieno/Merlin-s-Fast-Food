<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Foods</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }

        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        tr:hover {
            background-color: #f5f5f5;
        }
    </style>
</head>
<body>
    <h1>Search Foods</h1>

    <form>
        <label for="food_id">Food ID:</label>
        <input type="text" id="food_id" name="food_id" placeholder="Enter Food ID">
        <button type="submit">Search</button>
    </form>

    <div id="search-results">
        <?php
        include('db_connection.php');

        // Get the logged-in restaurant name
        $restaurant_name = $_SESSION['restaurant_name'];

        // Get the food_id from the URL parameter
        $food_id = $_GET['food_id'] ?? '';

        // Query to retrieve data from cart and users tables based on food_id
        $sql = "SELECT c.cartID, c.email AS cart_email, c.itemName, c.itemPrice, c.amount, c.date, c.status, u.telephone, u.address, u.id AS user_id
                FROM cart AS c
                INNER JOIN users AS u ON c.email = u.email
                WHERE c.itemRestaurant = '$restaurant_name' AND c.cartID = '$food_id'";

        $result = $conn->query($sql);

        // Check if there are any results
        if ($result->num_rows > 0) {
            echo '<table>';
            echo '<tr>
                    <th>User ID</th>
                    <th>User Telephone</th>
                    <th>User Address</th>
                    <th>Food ID</th>
                    <th>Food Name</th>
                    <th>Times</th>
                    <th>Price</th>
                    <th>Date</th>
                    <th>Status</th>
                  </tr>';

            // Output data of each row
            while ($row = $result->fetch_assoc()) {
                $cartID = $row['cartID'];
                $cart_email = $row['cart_email'];
                $itemName = $row['itemName'];
                $itemPrice = $row['itemPrice'];
                $amount = $row['amount'];
                $date = $row['date'];
                $status = $row['status'];
                $telephone = $row['telephone'];
                $address = $row['address'];
                $user_id = $row['user_id'];

                echo '<tr>
                        <td>' . $user_id . '</td>
                        <td>' . $telephone . '</td>
                        <td>' . $address . '</td>
                        <td>' . $cartID . '</td>
                        <td>' . $itemName . '</td>
                        <td>' . $amount . '</td>
                        <td>' . $itemPrice . '</td>
                        <td>' . $date . '</td>
                        <td>' . $status . '</td>
                      </tr>';
            }
            echo '</table>';
        } else {
            echo "<p>No results found.</p>";
        }

        // Close the database connection
        $conn->close();
        ?>
    </div>

</body>
</html>