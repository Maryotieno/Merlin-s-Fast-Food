<?php
session_start();

include('db_connection.php');

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $restaurant_name = $_POST['restaurant_name'];
    $password = $_POST['password'];

    // Check if restaurant exists in the database
    $query = "SELECT * FROM restaurants WHERE restaurant_name = '$restaurant_name'";
    $result = $conn->query($query);

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        // Verify password
        if (password_verify($password, $row['password'])) {
            // Password is correct, set session and redirect
            $_SESSION['restaurant_name'] = $restaurant_name;
            header("Location: sellerdashboard.php?success=Login successful");
            exit(); // Ensure script execution stops after redirection
        } else {
            header("Location: restaurant_loginn.php?error=Invalid password");
            exit();
        }
    } else {
        header("Location: restaurant_loginn.php?error=No such restaurant found");
        exit();
    }
}

$conn->close();
?>
