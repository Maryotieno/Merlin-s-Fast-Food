<?php
include('db_connection.php');

// Check if staff ID is provided in the URL
if (isset($_GET['id'])) {
    // Sanitize the input to prevent SQL injection
    $staff_id = mysqli_real_escape_string($conn, $_GET['id']);

    // Prepare and execute SQL statement to delete staff member
    $sql = "DELETE FROM staffs WHERE id = ?";
    $stmt = $conn->prepare($sql);

    // Bind the staff ID parameter to the prepared statement
    $stmt->bind_param("i", $staff_id);

    // Execute the statement
    if ($stmt->execute()) {
        // Staff member deleted successfully
        header("Location: restaurantstaffs.php?success=Staff member deleted successfully.");
        exit();
    } else {
        // Error occurred while deleting staff member
        header("Location: restaurantstaffs.php?error=Error: Unable to delete staff member. Please try again.");
        exit();
    }
} else {
    // Redirect to the staff list page with an error message if staff ID is not provided
    header("Location: restaurantstaffs.php?error=Error: Staff ID not provided.");
    exit();
}

// Close the database connection
$conn->close();
?>
