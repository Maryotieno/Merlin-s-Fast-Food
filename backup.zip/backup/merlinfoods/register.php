<?php
session_start();

include('db_connection.php');

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $restaurant_name = $_POST['restaurant_name'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // Handle restaurant image upload
    $restaurant_image = uploadImage('restaurant_image', 'restaurants');

    $food_description = $_POST['food_description'];
    $phone_number = $_POST['phone_number'];
    $email = $_POST['email'];
    $address = $_POST['address'];

    // Insert data into restaurants table
    $restaurant_insert_query = "INSERT INTO restaurants (restaurant_name, password, restaurant_image, food_description, phone_number, email, address) VALUES ('$restaurant_name', '$password', '$restaurant_image', '$food_description', '$phone_number', '$email', '$address')";

    if ($conn->query($restaurant_insert_query) === TRUE) {
        echo "Restaurant registered successfully.";
        $_SESSION['restaurant_name'] = $restaurant_name;
        header("Location: restaurant_login.html");
    } else {
        echo "Error: " . $restaurant_insert_query . "<br>" . $conn->error;
    }
}

$conn->close();

function uploadImage($fileInputName, $uploadDirectory)
{
    $target_dir = $uploadDirectory . '/images';  // Adjust this directory accordingly
    $target_file = $target_dir . basename($_FILES[$fileInputName]["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));



    // Check if the file already exists
    if (file_exists($target_file)) {
        echo "Sorry, file already exists.";
        $uploadOk = 0;
    }



    // Allow certain file formats
    if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif") {
        echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
        $uploadOk = 0;
    }

    // Check if $uploadOk is set to 0 by an error
    if ($uploadOk == 0) {
        echo "Sorry, your file was not uploaded.";
    } else {
        if (move_uploaded_file($_FILES[$fileInputName]["tmp_name"], $target_file)) {
            echo "The file " . htmlspecialchars(basename($_FILES[$fileInputName]["name"])) . " has been uploaded.";
            return $target_file;  // Return the uploaded file path
        } else {
            echo "Sorry, there was an error uploading your file.";
        }
    }

    return "";  // Return an empty string if the upload fails
}
?>
