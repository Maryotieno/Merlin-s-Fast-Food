<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Restaurants</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 20px;
        }

        .restaurant {
            background-color: #fff;
            border-radius: 5px;
            padding: 10px;
            margin-bottom: 15px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease-in-out;
        }

        .restaurant:hover {
            transform: scale(1.03);
        }

        .restaurant h2 {
            margin-bottom: 5px;
            color: #333;
        }

        .restaurant p {
            margin: 0;
            color: #666;
        }

        .restaurant a {
            text-decoration: none;
            color: #007bff;
            font-weight: bold;
        }

        .restaurant a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <h1>List of Restaurants</h1>
    <div class="restaurant">
        <h2><a href="sellerdashboard.php1">cabanas</a></h2>
        <p>Description of Restaurant 1...</p>
    </div>
    <div class="restaurant">
        <h2><a href="sellerdashboard.php">ashley's</a></h2>
        <p>Description of Restaurant 2...</p>
    </div>
    <div class="restaurant">
        <h2><a href="sellerdashboard.php">nector</a></h2>
        <p>Description of Restaurant 3...</p>
    </div>
    <div class="restaurant">
        <h2><a href="sellerdashboard.php">yummy chicken</a></h2>
        <p>Description of Restaurant 4...</p>
    </div>
    <div class="restaurant">
        <h2><a href="rest.php">Restaurant 5</a></h2>
        <p>Description of Restaurant 5...</p>
    </div>
</body>
</html>
