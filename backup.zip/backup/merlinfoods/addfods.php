<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Food Details</title>
</head>
<body>
    <h1>Add Food Details</h1>
    <form action="insert_data.php" method="post" enctype="multipart/form-data">
        <label for="food_menu">Food Menu:</label>
        <select id="food_menu" name="food_menu" required>
            <option value="breakfast">Breakfast</option>
            <option value="lunch">Lunch</option>
            <option value="dinner">Dinner</option>
            <option value="snack">Snack</option>
            <option value="drinks">Drinks</option>
        </select><br>

        <label for="food_name">Food Name:</label>
        <input type="text" id="food_name" name="food_name" required><br>

        <label for="food_image">Food Image:</label>
        <input type="file" id="food_image" name="food_image" accept="image/*" required><br>
        
        <label for="price">Price:</label>
        <input type="text" id="price" name="price" required><br>

        <input type="submit" value="Add Food">
    </form>
</body>
</html>
