<?php
// Include database connection
include('db_connection.php');

// Initialize variables for start date and end date
$start_date = $_GET['start_date'];
$end_date = $_GET['end_date'];

// Initialize arrays to hold data
$data = [];

// SQL query to fetch data from transactions table for the chosen date range
$sql_transactions = "SELECT SUM(total_amount) AS total_amount FROM transactions WHERE transaction_date BETWEEN ? AND ?";
$stmt_transactions = $conn->prepare($sql_transactions);
$stmt_transactions->bind_param("ss", $start_date, $end_date);
$stmt_transactions->execute();
$result_transactions = $stmt_transactions->get_result();
$row_transactions = $result_transactions->fetch_assoc();
$total_amount = $row_transactions['total_amount'];

// SQL query to fetch data from staffs table for the chosen date range
$sql_salary = "SELECT SUM(salary) AS total_salary FROM staffs WHERE join_date BETWEEN ? AND ?";
$stmt_salary = $conn->prepare($sql_salary);
$stmt_salary->bind_param("ss", $start_date, $end_date);
$stmt_salary->execute();
$result_salary = $stmt_salary->get_result();
$row_salary = $result_salary->fetch_assoc();
$total_salary = $row_salary['total_salary'];

// Calculate profit
$profit = $total_amount - $total_salary;

// Prepare data array
$data['total_amount'] = $total_amount;
$data['total_salary'] = $total_salary;
$data['profit'] = $profit;

// Return JSON response with filtered data
header('Content-Type: application/json');
echo json_encode($data);

// Close prepared statements
$stmt_transactions->close();
$stmt_salary->close();

// Close the database connection
$conn->close();
?>
