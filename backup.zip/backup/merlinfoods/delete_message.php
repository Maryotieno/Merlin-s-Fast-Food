<?php
// Include the file containing the database connection logic
include 'db_connection.php';

// Start the session
session_start();

// Check if message_id is provided in the URL
if(isset($_GET['message_id'])) {
    // Sanitize the message_id to prevent SQL injection
    $messageId = htmlspecialchars($_GET['message_id']);

    try {
        // Connect to the database
        $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
        // Set the PDO error mode to exception
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Prepare the SQL statement to delete the message
        $sql = "DELETE FROM `messages` WHERE `message_id` = :message_id";

        // Prepare the query
        $stmt = $conn->prepare($sql);
        // Bind parameters
        $stmt->bindParam(':message_id', $messageId);
        // Execute the query
        $stmt->execute();

        // Set success message
        $_SESSION['success_message'] = "Message deleted successfully.";
    } catch(PDOException $e) {
        // Handle database connection errors
        $_SESSION['error_message'] = "Error: " . $e->getMessage();
    }

    // Close the database connection
    $conn = null;

    // Redirect back to the messages page
    header("Location: restaurantmessages.php");
    exit();
} else {
    // Set error message if message_id is not provided
    $_SESSION['error_message'] = "Message ID not provided.";
    // Redirect to the messages page
    header("Location: restaurantmessages.php");
    exit();
}
?>
