<?php
session_start();

include('db_connection.php');

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data and sanitize inputs
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $role = mysqli_real_escape_string($conn, $_POST['role']);
    $salary = mysqli_real_escape_string($conn, $_POST['salary']);
    $restaurant_name = mysqli_real_escape_string($conn, $_POST['restaurant_name']);
    $phone_number = mysqli_real_escape_string($conn, $_POST['phone_number']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    // Hash the password securely
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Prepare SQL statement to insert staff details
    $sql = "INSERT INTO staffs (name, email, role, salary, restaurant_name, phone_number, address, password) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);

    // Check if the statement was prepared successfully
    if ($stmt) {
        // Bind parameters to the prepared statement
        $stmt->bind_param("ssssssss", $name, $email, $role, $salary, $restaurant_name, $phone_number, $address, $hashed_password);

        // Execute the statement
        if ($stmt->execute()) {
            // Staff details inserted successfully
            $_SESSION['success_message'] = "Staff added successfully.";
        } else {
            // Error occurred while inserting staff details
            $_SESSION['error_message'] = "Error: Unable to add staff. Please try again.";
        }
    } else {
        // Error occurred while preparing the statement
        $_SESSION['error_message'] = "Error: Unable to prepare statement. Please try again.";
    }

    // Redirect back to the form page with appropriate message
    header("Location: restaurantstaffs.php");
    exit();
}

// Close the database connection
$conn->close();
?>
