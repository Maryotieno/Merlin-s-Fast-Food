<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="static/admin.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.7.0/chart.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
    <div class="admin_page">
        <div class="side_bar">
            <div class="company_name">MERLIN FOOD <br> <p>DELIVERY</p></div>
            <div class="myrestaurant" style="background-image: url(./images/ashley.png);background-size: cover; background-position: center; background-repeat: no-repeat; width: 80%; height: 25%;margin-left:10%;border-radius:10px;">
                <div class="restaurant_name">AdMIN</div>
            </div>
            <ul>
                <li onclick="openTab('dashboard')"><div class="lists"><i class="fa fa-dashboard"></i> Dashboard</div></li>
                <li onclick="openTab('restaurants')"><div class="lists"><i class="fa fa-cutlery"></i> Restaurants</div></li>
                <li onclick="openTab('users')"><div class="lists"><i class="fa fa-user-circle"></i> Users</div></li>
                <li onclick="openTab('messages')"><div class="lists"><i class="fa fa-envelope"></i> Messages</div></li>
            </ul>
            <hr>
        </div>
        <div class="main_bar">
            <div class="tab_content active " id="dashboardContent">
                <div class="top_bar">
                    <div class="bar_name">
                        Dashboard
                    </div>
                    <div class="accs">
                        <div>
                            welcome admin
                        </div>
                        <div>
                            <a href="adminlogout.php">Logout</a>
                        </div>
                    </div>
                </div> 
                <div class="dashboard_boxes">
                    <!-- Dashboard statistics here -->
                </div> 
                <div class="bottom">
                    <div class="aob">
                        <div class="filter">
                            <!-- Download CSV button -->
                            
                            <!-- Button to print PDF using TCPDF -->
                            <button id="download_pdf" onclick="generatePDF();">Download PDF</button>
                        </div>
                        <canvas id="profitLossChart"></canvas>
                        <script>
                            var ctxProfitLoss = document.getElementById('profitLossChart').getContext('2d');
                            // Chart.js code here
                        </script>
                    </div>
                </div>
            </div>
            <div class="tab_content " id="restaurantsContent">
                <!-- Restaurants tab content -->
            </div>
            <div class="tab_content" id="usersContent">
                <!-- Users tab content -->
            </div>
            <div class="tab_content" id="messagesContent">
                <!-- Messages tab content -->
            </div>
        </div>
    </div>

    <script>
        function openTab(tabId) {
            document.querySelectorAll('.tab_content').forEach(function(tabContent) {
                tabContent.classList.remove('active');
            });
            document.getElementById(tabId + 'Content').classList.add('active');
        }

        function generatePDF() {
            // Get HTML content of the page
            var htmlContent = document.documentElement.outerHTML;

            // Send HTML content to generate PDF using TCPDF
            var xhr = new XMLHttpRequest();
            xhr.open('POST', 'generate_pdf.php', true);
            xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
            xhr.responseType = 'blob'; // Set response type to blob for PDF file
            xhr.onload = function() {
                var blob = new Blob([this.response], { type: 'application/pdf' });
                var url = window.URL.createObjectURL(blob);

                // Create a temporary anchor element for download
                var a = document.createElement('a');
                a.href = url;
                a.download = 'report.pdf'; // Set the filename for the downloaded PDF
                a.style.display = 'none'; // Hide the anchor element
                document.body.appendChild(a);

                // Trigger the click event to start the download
                a.click();

                // Clean up after download
                document.body.removeChild(a);
                window.URL.revokeObjectURL(url);
            };
            xhr.send('html_content=' + encodeURIComponent(htmlContent));
        }
    </script>
</body>
</html>
