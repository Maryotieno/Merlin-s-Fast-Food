<?php
include("db_connection.php");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $first_name = mysqli_real_escape_string($conn, $_POST["first_name"]);
    $last_name = mysqli_real_escape_string($conn, $_POST["last_name"]);
    $username = mysqli_real_escape_string($conn, $_POST["username"]);
    $email = mysqli_real_escape_string($conn, $_POST["email"]);
    $telephone = mysqli_real_escape_string($conn, $_POST["telephone"]); // Add this line
    $password = password_hash($_POST["password"], PASSWORD_DEFAULT);

    // Check if username or email already exists
    $checkQuery = "SELECT * FROM `users` WHERE `username` = '$username' OR `email` = '$email'";
    $result = mysqli_query($conn, $checkQuery);

    if (mysqli_num_rows($result) > 0) {
        // Redirect back to the registration page with an error message
        header("Location: registration.php?error=Username or email already exists");
        exit(); // Ensure script execution stops after redirection
    } else {
        // If username and email are unique, proceed with registration
        $insertQuery = "INSERT INTO `users` (`first_name`, `last_name`, `username`, `email`, `telephone`, `password`)
                      VALUES ('$first_name', '$last_name', '$username', '$email', '$telephone', '$password')";

        if (mysqli_query($conn, $insertQuery)) {
            // Redirect to the login page upon successful registration
            header("Location: login_page.php");
            exit(); // Ensure script execution stops after redirection
        } else {
            // Redirect back to the registration page with an error message
            header("Location: registration.php?error=Error registering user");
            exit(); // Ensure script execution stops after redirection
        }
    }
}
?>
