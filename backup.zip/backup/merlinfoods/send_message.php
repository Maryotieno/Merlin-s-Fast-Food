<?php
include('db_connection.php');
session_start(); // Start the session

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate input and sanitize it
    $restaurant_name = $_POST['restaurant_name'];
    $message = htmlspecialchars($_POST['message']); // Sanitize input
    $sender_email = isset($_POST['sender_email']) ? filter_var($_POST['sender_email'], FILTER_VALIDATE_EMAIL) : null; // Validate and sanitize input

    // Check if the restaurant name and message are provided
    if (empty($restaurant_name) || empty($message)) {
        $_SESSION['feedback'] = "Restaurant name and message are required.";
    } elseif ($sender_email === false) {
        $_SESSION['feedback'] = "Invalid email format.";
    } else {
        // Insert message into the database
        $insert_query = "INSERT INTO messages (restaurant_name,  sender_email, message_content) 
                         VALUES ('$restaurant_name',  '$sender_email', '$message')";

        if ($conn->query($insert_query) === TRUE) {
            $_SESSION['feedback'] = "Message sent successfully.";
        } else {
            $_SESSION['feedback'] = "Error: " . $insert_query . "<br>" . $conn->error;
        }
    }
} else {
    $_SESSION['feedback'] = "Invalid request.";
}

$conn->close();

// Redirect back to the form page
header("Location: index.php");
exit();
?>
