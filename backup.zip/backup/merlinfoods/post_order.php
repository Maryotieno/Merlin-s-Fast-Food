<?php


    header('Content-Type:application/json');

    include("db_connection.php");

    if ($_SERVER["REQUEST_METHOD"] == "POST") { // Fix typo in REQUEST_METHOD
        $name = isset($_POST["name"]) ? $_POST["name"] : null;
        $restaurant = isset($_POST["restaurant"]) ? $_POST["restaurant"] : null;
        $amount = isset($_POST["amount"]) ? $_POST["amount"] : null;
        $price = isset($_POST["price"]) ? $_POST["price"] : null;
        $email = isset($_POST["email"]) ? $_POST["email"] : null;

        if ($name !== null) {
            // Process the data as needed
            $query = "INSERT INTO `cart`(`cartID`, `itemName`, `itemRestaurant`, `itemPrice`,`amount`, `email`) VALUES ('','$name','$restaurant','$price','$amount','$email')";
            mysqli_query($conn, $query);
            $response = ['message' => 'Data received successfully', 'name' => $name, 'restaurant' => $restaurant, 'price' => $price, 'amount' => $amount];
            echo json_encode($response);

            // if(mysqli_query($conn, $query)) {
            //     echo json_encode($response);
            // } else {
            //     http_response_code(500); // Internal Server Error
            //     echo json_encode(['error' => 'Error inserting data into the database']);
            // }

        } else {
            http_response_code(400); // Bad Request
            echo json_encode(['error' => 'Missing or invalid parameters']);
        }
    } else {
        http_response_code(405); // Method Not Allowed
        echo json_encode(['error' => 'Method Not Allowed']);
    }
?>
