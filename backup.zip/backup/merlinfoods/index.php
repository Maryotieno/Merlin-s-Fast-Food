<?php
session_start();
include "db_connection.php";

// Check if the email is stored in the session
if (isset($_SESSION['email'])) {
    // Retrieve the email from the session
    $email = $_SESSION['email'];

    // Query to retrieve cart data for the logged-in user
    $sql = "SELECT * FROM cart WHERE email = '$email'";

    // Perform the query
    $result = mysqli_query($conn, $sql);

    // Check if there are any results
    if (mysqli_num_rows($result) > 0) {
        // Loop through each row of the result set
        while ($row = mysqli_fetch_assoc($result)) {
            // Access data from the row
            $cartID = $row['cartID'];
            $itemName = $row['itemName'];
            $itemRestaurant = $row['itemRestaurant'];
            $itemPrice = $row['itemPrice'];
            $amount = $row['amount'];
            $status = $row['status'];
            $date = $row['date'];

            // Do something with the retrieved data, like display it
        // echo "cartID: $cartID, Item Name: $itemName, Item Restaurant: $itemRestaurant, Item Price: $itemPrice, Amount: $amount,$date,$status <br>";
        }
    } else {
        // echo "No items found in the cart for this user.";
    }

    // Close the database connection
    mysqli_close($conn);
} else {
    // echo "Email not found in the session.";
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MerlinFoods</title>
    <link rel="stylesheet" href="static/index.css">
    <script src="static/script.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    
</head>
<body>
    <div class="main_area">
        <div class="top_nav">
            <div class="menu_bar" >
                
                <i class="fa fa-bars" onclick="sidenav()"></i>
            </div>
            
            <div class="company_name"  id="hidename">
                Merlin Foods
            </div>
            <div class="retaurant_header" id="showname">
                Serve from Top Restaurants
            </div>
            <div class="foods_content_header"id="search">
                <input type="text"  id="food_search" placeholder="Search foods" onkeyup="searchFoods()" placeholder="Search foods">
                <li onclick="showContent('main')">Home</li>
                <i class="fa fa-search"></i>
                <li onclick="showContent('main')">Home</li>
            </div>
            <ul id="hidemenu">
                <li onclick="showContent('main')">Home</li>
                <li onclick="showContent('service')">Services</li>
                <li onclick="showContent('restaurants')">Restaurants</li>
                <li onclick="showContent('foods')">Foods</li>
                <!-- <li onclick="showContent('about')">About us</li> -->
                <li onclick="showContent('contact')">Contacts</li>
                <li><a href="admin_login.php"> admin</a></li>
                <li><a href="staff_login_form.php">staff</a></li>
            </ul>
            <div class="accounts">
            <?php
                        // Check if the user is logged in using the session variable
                        if (isset($_SESSION['email'])) :
                        ?>
                <div class="carts">
                    <div class="itemCount" id="itemCount">0</div>
                    <i class="fa fa-shopping-cart" onclick="opencart()"></i>
                </div>
                <?php
                    else :
                    ?>
                    <div></div>
                    <?php
                    endif;
                    ?>
                <div>
                    <?php
                        // Check if the user is logged in using the session variable
                        if (isset($_SESSION['email'])) :
                        ?>
                        <div class="order" id="hideorder" onclick="openProfile()">Account</div>
                        
                    <?php
                    else :
                    ?>
                    <div id="hidelogin" class="login"><a href="login_page.php">Login</a></div>
                    <?php
                    endif;
                    ?>
                </div>
            </div>
        </div>
        <div class="content_tab">
        <!-- transactions tab -->
        <div id="home-content" class="content">
            <div class="main" onclick="showContent('main')">.</div>
            <div class="foods" onclick="showContent('foods')">FOODS</div>
            <div class="restaurants" onclick="showContent('restaurants')">RESTAURANTS</div>
            <div class="order_button" onclick="showContent('foods')">ORDER ONLINE</div>
        </div>
        <!-- FOODS -->
        <div id="foods-content" class="content">
            <div class="foods_cards_content">
                <div class="view_food_card">

                    <?php
                    include('db_connection.php');

                    $foods_query = "SELECT * FROM foods";
                    $result_foods = $conn->query($foods_query);
                    

                    if ($result_foods->num_rows > 0) {
                        while ($row = $result_foods->fetch_assoc()) {
                            // Open the food card container for each row
                            ?>
                            
                            <div class="food_card">
                                <div class="food_card_image">
                                    <img src="<?php echo $row['food_image']; ?>" alt="" width="100%" height="100%">
                                </div>
                                <div class="food_card_description">
                                    <div>
                                        <div class="food_card_name">
                                            <?php echo $row['food_name']; ?>
                                            <div class="food_restaurant"><?php echo $row['restaurant_name']; ?></div>
                                        </div>
                                    </div>
                                    <div class="food_card_price"><?php echo $row['price']; ?></div>
                                </div>

                                <!-- Display order button -->
                                <div class="card_order">
                                    <div class="buy"  id="shop" onclick="showDetails(this, '<?php echo $row['food_name']; ?>', '<?php echo $row['restaurant_name']; ?>', '<?php echo $row['food_image']; ?>', '<?php echo $row['price']; ?>', ' <?php echo $row['food_id'] ?>')">Buy now</div>
                                    <i class="fa fa-shopping-cart" id="shop" onclick="showDetails(this, '<?php echo $row['food_name']; ?>', '<?php echo $row['restaurant_name']; ?>', '<?php echo $row['food_image']; ?>', '<?php echo $row['price']; ?>', ' <?php echo $row['food_id'] ?>')"></i>
                                </div>
                            </div>
                            <?php
                        }
                    } else {
                        echo "No foods found.";
                    }
                    ?>
                </div>
                <script>
                function searchFoods() {
                        var input, filter, cards, card, foodName, i, txtValue;
                        input = document.getElementById("food_search");
                        filter = input.value.toUpperCase();
                        cards = document.getElementsByClassName("food_card");

                        for (i = 0; i < cards.length; i++) {
                            card = cards[i];
                            foodName = card.getElementsByClassName("food_card_name")[0];
                            txtValue = foodName.textContent || foodName.innerText;
                            if (txtValue.toUpperCase().indexOf(filter) > -1) {
                                card.style.display = "";
                            } else {
                                card.style.display = "none";
                            }
                        }
                    }
                </script>
            </div>
        </div>
        <div id="restaurants-content" class="content">
        
            <div class="restaurant_tab">
                <?php
                include('db_connection.php');

                // SELECT query for retrieving data from the restaurants table
                $restaurants_query = "SELECT * FROM restaurants";

                $result_restaurants = $conn->query($restaurants_query);

                if ($result_restaurants->num_rows > 0) {
                    while ($row = $result_restaurants->fetch_assoc()) {
                        echo ' <div class="restaurant_card">';

                        // Echo HTML for each row of data
                        echo '<div class="top_retaurant_name">' . $row["restaurant_name"] . '</div>';
                        echo '<div class="top_retaurant_pics">';
                        echo '<img src="' . $row["restaurant_image"] . '" width="100%" height="100%">';
                        echo '<div class="overlay-description">';
                        echo '<div class="foods_name">What we serve?</div>';
                        echo '<div class="top_restaurants_food_cards">';
                        echo '<ul>';
                        echo '<li>' . $row["food_description"] . '</li>';
                        echo '<li><i class="fa fa-map-marker"></i>' . $row["address"] . '</li>';
                        echo '<li>' . $row["email"] . '</li>';
                        echo '</ul>';
                        echo '<div class="order_top_restaurant">Order Now</div>';
                        echo '</div>';
                        echo '</div>';
                        // echo '<div class="overlay-button" onclick="showContent(\'viewrestaurant\')">';
                        // echo '<div class="view_top_restaurant">View</div>';
                        // echo '</div>';
                        echo '<div class="overlay-button" onclick="showContent(\'viewrestaurant\'); showRestaurantDetails(\'' . $row["restaurant_name"] . '\')">';
                        echo '<div class="view_top_restaurant">View</div>';
                        echo '</div>';
                                                    echo '</div>';
                        echo '</div>';
                    }
                } else {
                    echo "No restaurants found.";
                }

                $conn->close();
                ?>
            </div>
            
        </div>
        <div id="order-content" class="content">            
        </div>
        <!-- services -->
        <div id="service-content" class="content">
        <div class="service_page">
                    <div class="service">
                        <h2>Explore the magic <br> in tasty foods</h2>
                        <div class="par">
                        We offer a diverse range of culinary delights tailored to satisfy every palate. From savory starters to delectable desserts, our platform connects you with a plethora of restaurants and eateries, each offering their unique specialties.
                        Discover a world of flavors with our extensive menu options, ranging from local favorites to international cuisines. Whether you're craving classic comfort foods, exotic delicacies, or healthy alternatives, our platform ensures that there's something for everyone.
                        Experience the convenience of browsing through menus, placing orders, and arranging deliveries all from the comfort of your home or office. With seamless integration of payment gateways and real-time order tracking, we prioritize efficiency and reliability, ensuring a hassle-free dining experience.
                        Our commitment to quality extends beyond just food; we partner with reputable restaurants known for their exceptional culinary standards and hygiene practices. 
                        </div>
                        <div class="orderbutton" onclick="showContent('foods')">order now</div>
                    </div>
                    <div class="restaurants_service">
                        <div class="resdesign">
                        <h2>Explore the Top Notch <br> Restaurants</h2>
                        <div class="par">
                            Welcome to our online food ordering platform, where a world of culinary delights awaits you! Our curated selection of restaurants offers something for every taste and occasion, ensuring a diverse and satisfying dining experience for all.
                            Explore a myriad of flavors and cuisines from the comfort of your home or office. Whether you're in the mood for savory delights, spicy adventures, wholesome eats, or indulgent treats, our partner restaurants have you covered.
                            Savor the richness of [Restaurant Name 1]'s traditional dishes, where each bite tells a story of culinary craftsmanship and heritage. Delight in the bold and aromatic flavors of [Restaurant Name 2], where spices reign supreme and every dish is a journey to distant lands.                        </div>
                        <div class="orderbutton" onclick="showContent('restaurants')">visit</div>

                        </div>
                    </div>
                    <div class="delivery_service">
                        <div class="resdesign">
                        <h2>Explore the magic <br> in tasty foods</h2>
                        <div class="par">

                        Certainly! Here's an overall description of the restaurants available in our online food ordering system:
                            Welcome to our online food ordering platform, where a world of culinary delights awaits you! Our curated selection of restaurants offers something for every taste and occasion, ensuring a diverse and satisfying dining experience for all.
                            Explore a myriad of flavors and cuisines from the comfort of your home or office. Whether you're in the mood for savory delights, spicy adventures, wholesome eats, or indulgent treats, our partner restaurants have you covered.
                            Savor the richness of [Restaurant Name 1]'s traditional dishes, where each bite tells a story of culinary craftsmanship and heritage. Delight in the bold and aromatic flavors of [Restaurant Name 2], where spices reign supreme and every dish is a journey to distant lands.                        </div>
                        <div class="orderbutton" onclick="showContent('restaurants')">visit</div>

                        </div>
                    </div>
                </div>
        </div>
        <div id="about-content" class="content">
            <!-- Content for About Us -->
            <p>This is the content for about us.</p>
        </div>
        <div id="viewrestaurant-content" class="content" >
            <div class="details"id="restaurantDetailsContainer">
                

            </div>
        </div>
        <!-- sign up content -->
        <div id="signup-content" class="content">
        </div>
        <!-- contacts content -->
        <div id="contact-content" class="content">
            <div class="flec">
            <form action="submit_contact_form.php" method="POST" class="submit_contact">
                    <h2 style="text-align:center;">Send a messsage to us</h2>
                <div>
                    <input type="email" id="email" name="email" value="<?php echo $_SESSION['email']; ?>" required>
                </div>
                <div>
                    <textarea id="message" name="message" required style="padding:70px 90px;"placeholder="write your message"></textarea>
                </div>
                <button type="submit" style="padding:15px 153px;background-color:green;">Send</button>
                <div id="confirmation_message" style="text-align:center;"></div>
                <script>
                    document.addEventListener('DOMContentLoaded', function () {
                        const form = document.querySelector('.submit_contact');

                        form.addEventListener('submit', function (event) {
                            event.preventDefault(); // Prevent form submission

                            // Fetch API to submit form data
                            fetch('submit_contact_form.php', {
                                method: 'POST',
                                body: new FormData(form)
                            })
                            .then(response => response.json())
                            .then(data => {
                                // Display confirmation message
                                const confirmationMessage = document.getElementById('confirmation_message');
                                confirmationMessage.textContent = data.message;

                                // Clear form inputs if submission was successful
                                if (data.success) {
                                    form.reset();
                                }
                            })
                            .catch(error => console.error('Error:', error));
                        });
                    });
                </script>
            </form>       
            </div>
        </div>
        <!-- login content -->
        <div id="login-content" class="content">

        </div>
        <!-- side menu -->
        <div id="menu" class="side_nav">
            <ul>
                <li onclick="showContent('main')">Home</li>
                <li onclick="showContent('service')">Services</li>
                <li onclick="showContent('restaurants')">Restaurants</li>
                <li onclick="showContent('foods')">Foods</li>
                <!-- <li onclick="showContent('about')">About us</li> -->
                <li onclick="showContent('contact')">Contacts</li>
            </ul>
            <div class="side_nav_order" onclick="showContent('foods')">Order Online</div>
            <div  onclick="showContent('login')" class="side_nav_login">Logout</div>
        </div>

            <!-- carts -->
        <div class="checkout" id="checkout">
            <div class="checkout_header">Cart</div>
            <div class="cart_content" id="cart">
            </div>
            
            <div class="cart_footer">
                <div class="total_price">Total</div>
                <div class="amount">0</div>
                <div class="check_out_button" onclick="openOrder()">Check Out</div>
            </div>
        </div>
    
            <!-- delivery -->
        <div class="delivery" id="cartOrder">
            <div class="delivery_header">Delivery</div>
                <div class="delivery_address"><i class="fa fa-map-marker"></i>
                <?php
        // Start or resume the session

        // Check if the email is set in the session
        if(isset($_SESSION['email'])) {
            // Get the email from the session
            $email = $_SESSION['email'];

            try {
                // Include the file containing the database connection logic
                include 'db_connection.php';

                // Connect to the database
                $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
                // Set the PDO error mode to exception
                $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                $sql = "SELECT `address` FROM `users` WHERE `email` = :email";
                $stmt = $conn->prepare($sql);
                $stmt->bindParam(':email', $email);
                $stmt->execute();
                $result = $stmt->fetch(PDO::FETCH_ASSOC);
                if ($result) {
                } else {
                    echo "No address found for email '$email'";
                }
            } catch(PDOException $e) {
                echo "Error: " . $e->getMessage();
            }

            // Close the database connection
            $conn = null;
        } else {
            echo "Email not set in session.";
        }
        ?>

    <div class="addresses">
        My Address
        <?php  echo  $result['address']; ?>
        
    </div>
    <div id="address_update_form" style="display: none;">
        <form action="update_address.php" method="POST">
            <label for="new_address">New Address:</label><br>
            <input type="text" id="new_address" name="new_address" required><br>
            <input type="submit" value="Submit">
        </form>
    </div>
    <div class="change_address">
    <button id="change_address_button">Change</button>
    </div>
</div>

<div class="delivery_period">
<i class="fa fa-calendar"></i>
<div>Estimated delivery time</div>
<div id="estdate" class="estdate"></div>
<!-- <div id="esttime" class="esttime"></div> -->
</div>
<div class="total_products"> 
<div class="item" id="countItem">0</div><p style="margin-left:-50%;">items</p>
<div style="color: orange;" onclick="backtocart()">view items</div>
</div>
<div class="delivery_prices">
<div  class="itemprice">
    <div>Total price</div><div  class="iprice">0</div>
</div>
<div class="dprice">
    <div>Delivery cost</div><div style="margin-right:-50%;">Ksh</div><div class="deliv">99</div>
</div>
<div class="tprice">
    <div>Total Amount</div><div class="tota">0</div>
</div>
</div>
<div class="payments_button" onclick="openPaymentForm()">
Proceed To Payments
</div>
        </div>


            <!-- open orders -->
        <div class="order_details"id="openorder">
            <div class="order_details_menu">
                <ul>
                    <li><i class="fa fa-clock-o" onclick="openTab('waiting')"> Waiting Orders</i> </li>
                    <li><i class="fa fa-check" onclick="openTab('completed')"> Completed Orders</i> </li>
                    <li><i class="fa fa-ban" onclick="openTab('rejected')"> Cancelled Orders</i> </li>
                </ul>
              <i class="fa fa-close" onclick="closeOrder()" style="position:absolute;left:10%;font-size:18px;color:brown;"></i>
              <script>
                function closeOrder(){
                    document.getElementById ('openorder').style.display = "none"
                }
              </script>
            </div>
            <div class="transaction_tab">
            <div class="order_details_header">
                <ul>
                    <li>Food ID</li>
                    <li>Restaurant</li>
                    <li>Food Name</li>
                    <li>Amount</li>
                    <li>Cost</li>
                    <li>Date</li>
                    <li>Status</li>
                </ul>
            </div>
            <div id="waitingTab" class="orders_tab">
            <?php
                include "db_connection.php";

                // Check if the email is stored in the session
                if (isset($_SESSION['email'])) {
                // Retrieve the email from the session
                $email = $_SESSION['email'];

                // Query to retrieve cart data for the logged-in user
                $sql = "SELECT * FROM cart WHERE email = '$email' AND status = 'pending'";


                // Perform the query
                $result = mysqli_query($conn, $sql);

                // Check if there are any results
                if (mysqli_num_rows($result) > 0) {
                    // Output list container
                    
                    // Loop through each row of the result set
                    while ($row = mysqli_fetch_assoc($result)) {
                        // Output list items for each row
                        echo "<ul>";
                        echo "<li>" . $row['cartID'] . "</li>";
                        echo "<li>" . $row['itemRestaurant'] . "</li>";
                        echo "<li>" . $row['itemName'] . "</li>";
                        echo "<li>" . $row['amount'] . "</li>";
                        echo "<li>" . $row['itemPrice'] . "</li>";
                        echo "<li>" . $row['date'] . "</li>";
                        echo "<li><i class='fa fa-clock-o'> "   . $row['status'] . "</i></li>";
                        echo "</ul>";
                    }
                    
                    // Close list container
                } else {
                    echo "<div class='messages'><div class='message'>No pending orders  for this user.</div></div>";
                }

                // Close the database connection
                mysqli_close($conn);
                } else {
                echo "<div class='messages'><div class='message'>No pending orders  for this user.</div></div>";
                }
                ?>


            </div>
            <div id="completedTab" class="orders_tab">
                <?php
                include "db_connection.php";

                // Check if the email is stored in the session
                if (isset($_SESSION['email'])) {
                    // Retrieve the email from the session
                $email = $_SESSION['email'];

                // Query to retrieve cart data for the logged-in user
                $sql = "SELECT * FROM cart WHERE email = '$email' AND status = 'delivered'";


                // Perform the query
                $result = mysqli_query($conn, $sql);

                // Check if there are any results
                if (mysqli_num_rows($result) > 0) {
                    // Output list container
                    
                    // Loop through each row of the result set
                    while ($row = mysqli_fetch_assoc($result)) {
                        // Output list items for each row
                    echo "<ul>";
                    echo "<li>" . $row['cartID'] . "</li>";
                    echo "<li>" . $row['itemRestaurant'] . "</li>";
                    echo "<li>" . $row['itemName'] . "</li>";
                    echo "<li>" . $row['amount'] . "</li>";
                    echo "<li>" . $row['itemPrice'] . "</li>";
                    echo "<li>" . $row['date'] . "</li>";
                    echo "<li><i class='fa fa-clock-o'>" . $row['status'] . "</i></li>";
                    echo "</ul>";
                        }
                        
                        // Close list container
                    } else {
                        echo "<div class='messages'><div class='message'>No completed orders  for this user.</div></div>";
                    }

                    // Close the database connection
                    mysqli_close($conn);
                } else {
                    echo "<div class='messages'><div class='message'>No completed orders  for this user.</div></div>";

                }
                ?>
               </div>
                <div id="rejectedTab" class="orders_tab">
                <?php
                    include "db_connection.php";

                    // Check if the email is stored in the session
                    if (isset($_SESSION['email'])) {
                        // Retrieve the email from the session
                        $email = $_SESSION['email'];

                        // Query to retrieve cart data for the logged-in user
                        $sql = "SELECT * FROM cart WHERE email = '$email' AND status = 'cancelled'";


                        // Perform the query
                        $result = mysqli_query($conn, $sql);

                        // Check if there are any results
                        if (mysqli_num_rows($result) > 0) {
                            // Output list container
                            
                            // Loop through each row of the result set
                            while ($row = mysqli_fetch_assoc($result)) {
                                // Output list items for each row
                                echo "<ul>";
                                echo "<li>" . $row['cartID'] . "</li>";
                                echo "<li>" . $row['itemRestaurant'] . "</li>";
                                echo "<li>" . $row['itemName'] . "</li>";
                                echo "<li>" . $row['amount'] . "</li>";
                                echo "<li>" . $row['itemPrice'] . "</li>";
                                echo "<li>" . $row['date'] . "</li>";
                                echo "<li><i class='fa fa-clock-o'>" . $row['status'] . "</i></li>";
                                echo "</ul>";
                            }
                            
                            // Close list container
                        } else {
                            echo "<div class='messages'><div class='message'>No canceled orders  for this user.</div></div>";
                        }

                        // Close the database connection
                        mysqli_close($conn);
                    } else {
                        echo "Email not found in the session.";
                    }
                    ?>
                </div>
            </div>
        </div>

        <!-- open profiles -->
        <div class="profiles"id="profiles">
            <div class="user_profile">
                <img src="images/caban.png" alt=""height="100px" width="70%"style="border-radius:15px;">
                <div class="user_name"><?php echo $_SESSION['email']; ?> <i class="fa fa-pencil" onclick="openUpdate()"> </i></div>
            </div>
            <div class="profile_list">
                <ul>
                    <li><div class="mylist" onclick="openOrders()"><i class="fa fa-list"></i>My Orders</div></li>
                    <li onclick="openNotifications()"><div class="mylist"><i class="fa fa-bell"></i>Notifications</div></li>
                </ul>
            </div>
            <div class="logout"><i class="fa fa-power-off"></i><a href="logout.php">Logout</a></div>
            <!-- <a class="logout" href="logout.php"><i class="fa fa-power-off"></i> Logout</a>  </div>   -->

        </div>  

        <!-- open paynents -->
        <div class="delivery"id="paymentform" style="z-index:10;display:none;justify-content:center;align-items:center;">
            <form action="darajaapi\stkpush.php" class="payments_form">
                <h2 style="text-align:center;">Amount to Pay</h2><br>
                <div class="totalpay"style="text-align:center;">ksh 0</div><br>
                <input type="text" name="amount" id="amountToPay" hidden> 

                <input type="number" name="phone" placeholder="Enter mpesa number" style="padding:15px 40px;"><br><br>
                <input type="submit" value="pay"  style="padding:15px 105px;background-color: rgba(238, 53, 158, 0.8);">
            </form>
        </div>

        <!-- notifications -->
        <div class="notifications" id="notifications">
            <h2 style=text-align:center;>notifications</h2>
            <hr>
            <div class="notification_area">
                <?php
                    include "db_connection.php";

                    // Assuming $email is already defined from $_SESSION['email']

                    // Prepare and execute the SQL query to retrieve cart statuses
                    $sql = "SELECT c.`cartID`, c.`itemName`, c.`itemRestaurant`, c.`itemPrice`, c.`amount`, c.`date`, c.`status`, u.`username`, u.`username`
                            FROM `cart` AS c
                            JOIN `users` AS u ON c.`email` = u.`email`
                            WHERE c.`email` = '$email'";
                    $result = $conn->query($sql);

                    $html_output = '';

                    if ($result === false) {
                        // Handle query error
                        die("Query failed: " . $conn->error);
                    }

                    if ($result->num_rows > 0) {
                        // Loop through each row to display the cart statuses
                        while ($row = $result->fetch_assoc()) {
                            // Determine the status message based on the status value
                            $status_message = '';
                            switch ($row['status']) {
                                case 'pending':
                                    $status_message = 'in progress';
                                    break;
                                case 'cancelled':
                                    $status_message = 'has been cancelled';
                                    break;
                                case 'delivered':
                                    $status_message = 'has been delivered';
                                    break;
                                default:
                                    $status_message = 'is in an unknown state';
                                    break;
                            }

                            // Format the date
                            $formatted_date = date("d/m/Y", strtotime($row['date']));
                            

                            // Construct the HTML for each notification
                            $html_output .= '<div class="notify">';
                            $html_output .= '<p>Hello ' . $row['username'] . ', your order from ' . $row['itemRestaurant'] . ' Restaurant ' . $status_message . '</p>';
                            $html_output .= '<div style="display:flex;gap:20px;margin-top:10px;"><p style="margin-left: 70%;color:green;">' . $formatted_date . '</p><i class="fa fa-trash" style="color:brown; cursor: pointer;" onclick="deleteCartItem(' . $row['cartID'] . ')"></i></div>';
                            $html_output .= '</div>';
                        }
                    } else {
                        // If no rows are found, display a message
                        $html_output = '<p style="margin-left:30%;margin-top:50%;">You have no notifications.</p>';
                    }

                    // Output the HTML content
                    echo $html_output;
                    ?>
            </div>
        </div>

        <!-- updating user info -->
        <div class="user_update"id="update">
        <?php
            include "db_connection.php";

            // Fetch user details based on email
            $sql = "SELECT * FROM users WHERE email = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();

            // Check if user exists
            if($result->num_rows > 0) {
                // Fetch user details
                $user = $result->fetch_assoc();
                
                // Display the form with user details for editing
                echo '
                    <form action="update_user.php" method="post" class="update_form">
                        <input type="hidden" name="id" value="' . $user['id'] . '">
                        
                        <label for="first_name">First Name:</label><br>
                        <input type="text" id="first_name" name="first_name" value="' . $user['first_name'] . '"><br>
                        
                        <label for="last_name">Last Name:</label><br>
                        <input type="text" id="last_name" name="last_name" value="' . $user['last_name'] . '"><br>
                        
                        <label for="username">Username:</label><br>
                        <input type="text" id="username" name="username" value="' . $user['username'] . '"><br>
                        
                        <label for="email">Email:</label><br>
                        <input type="email" id="email" name="email" value="' . $user['email'] . '" readonly><br>
                        
                        <label for="telephone">Telephone:</label><br>
                        <input type="tel" id="telephone" name="telephone" value="' . $user['telephone'] . '"><br>
                        
                        <label for="address">Address:</label><br>
                        <textarea id="address" name="address">' . $user['address'] . '</textarea><br>
                                    
                        <input type="submit" value="Update">
                    </form>';
            } else {
                echo "User with provided email not found.";
            }

            // Close connection
            $conn->close();
            ?>
            <?php
             // Check if success message is present in session
            if(isset($_SESSION['success'])) {
                $successMessage = $_SESSION['success'];
                echo "<p style='color:green;'>$successMessage</p>";
                unset($_SESSION['success']); // Clear the success message
            }
            ?>

        </div>

        <div class="esc"onclick="hideNotifications()">
        </div>
        <div class="esc1"onclick="hideNotifications()">
        </div>



<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
    function openUpdate(){
        document.getElementById('update').style.display = 'block'
}
    function openNotifications(){
        document.getElementById('notifications').style.display = 'block'
}
    function hideNotifications(){
        document.getElementById('notifications').style.display = 'none'
        document.getElementById ('openorder').style.display = "none"
        document.getElementById ('update').style.display = "none"

}

</script>

<!-- delete notification -->

<script>
function deleteCartItem(cartID) {
    // Confirm with the user before deleting
    if (confirm("Are you sure you want to delete this notification?")) {
        // Make an AJAX request to delete the cart item
        $.ajax({
            type: 'POST',
            url: 'delete_cart_item.php', // Adjust the URL to the PHP script that handles the deletion
            data: { cartID: cartID },
            success: function(response) {
    // Display the response message
    alert(response);
    // If deletion is successful, remove the corresponding notification
    $('#notify_' + cartID).remove();
},
            error: function(error) {
                console.error('Error:', error);
                // Handle error if needed
            }
        });
    }
}

</script>
<script>
    function openTab(tabName) {
        var i;
        var tabs = document.getElementsByClassName("orders_tab");
        for (i = 0; i < tabs.length; i++) {
            tabs[i].style.display = "none";
        }
        document.getElementById(tabName + "Tab").style.display = "block";
    }
</script>


<script>
    let totalItems = 0;
    function updateItems(i){
        if (totalItems >= 0){
            totalItems = totalItems + i
            if (totalItems == -1){
                totalItems = 0;
            }
            document.querySelector('.number_counter').innerHTML = totalItems;
        }
    }
</script>

<script>
    // Function to handle item removal
    function removeItem(element) {
        // Get the parent checkout_details element
        var itemDetails = element.closest('.checkout_details');
        var cart = document.getElementById('cart');

        if (itemDetails) {
        // Get the total element within the itemDetails
            var totalElement = itemDetails.querySelector('.total');

            // Get the total amount for the item being removed
            var totalAmountToRemove = parseFloat(totalElement.textContent.replace('Total: Ksh ', '').trim()) || 0;
            console.log("totalAmountToRemove:" + totalAmountToRemove);

            // Update the overall total by subtracting the total amount for the item being removed
            var currentTotal = parseFloat(document.querySelector('.amount').textContent.replace('Ksh ', '').trim()) || 0;
            console.log("current Total:" + currentTotal);

            var newTotal = currentTotal - totalAmountToRemove;
            console.log("new total: " + newTotal);

            document.querySelector('.amount').textContent = 'Ksh ' + newTotal.toFixed(2);

            // Remove the itemDetails from the cart
            cart.removeChild(itemDetails);

            // Decrement the selected items count
            updateItemCount(-1);

            console.log("Removing item:", itemDetails);
            console.log("Total Amount Updated:", newTotal);
        }
    }

// Function to update selected items count
    function updateItemCount(amount) {
var itemCount = document.getElementById('itemCount');
var currentCountItem = document.getElementById('countItem');

// Update count for itemCount
var currentCount = parseInt(itemCount.textContent, 10) || 0;
var newCount = currentCount + amount;
itemCount.textContent = newCount;

// Update count for countItem
var currentCountItemValue = parseInt(currentCountItem.textContent, 10) || 0;
var newCountItem = currentCountItemValue + amount;
currentCountItem.textContent = newCountItem;

// Display count in the absolute div named 'countDisplay'
var countDisplay = document.getElementById('countDisplay');
countDisplay.textContent = newCount;

console.log("Count Updated:", newCount); // Add this line for debugging
}        

    // CARTS
    function showDetails(shop, name, restaurant, image, price) {
        // Check if the card has already been clicked
        if (shop.classList.contains('clicked')) {
            return;
        }

        // Get the cart element
        var cart = document.getElementById('cart');
        

        // Add the 'clicked' class to the card to mark it as clicked
        shop.classList.add('clicked');

        // Create a new div for the item details
        var itemDetails = document.createElement('div');
            itemDetails.classList.add('checkout_details'); // Use a class instead of an ID
            itemDetails.innerHTML = 
            `
            <div class="checkout_pic"><img src="${image}" alt="${name}" height="100%" width="100%"></div>
                <div class="food_details">
                    <div class="cart_food_name">
                        <div><p style="font-size:27px;" class="ordered_food_name">${name}</p> <p class="ordered_restaurant_name">${restaurant}</p> </div>
                        <div class="delete_food" onclick="removeItem(this)" style="color:red;">Remove item(s)</div>
                    </div>
                        <div class="cart_count">
                            <div style='margin-left:-25%; font-size:17px'>Ksh</div>
                            <div style='margin-left:-45%; font-size:17px' class="ordered_price_name">${price}</div>
                            <div style='margin-left:-45%; display:none;' class="user_email"><?php echo $_SESSION['email']; ?></div>
                            <div class="total" style="display:none;">Total: ksh 0</div> 
                            <div class="counter">
                                        <div class="minus" onclick="updateItems(this, -1)"> <i class="fa fa-minus"></i></div>
                                        <div class="number_counter">0</div>
                                        <div class="plus" onclick="updateItems(this, 1)"><i class="fa fa-plus"></i></div>
                            </div>
                    </div>
            `;

        // Append the item details to the cart without replacing existing content
        cart.appendChild(itemDetails);

        // Increment the selected items count
        updateItemCount(1);

        // Store the item details in localStorage for persistence
        localStorage.setItem('selectedItems', JSON.stringify({
            name,
            restaurant,
            image,
            price
        }));
    }

    // Function to update items with a specific amount
    function updateItems(element, amount) {
        // Handle quantity update logic here
        // You can use the element parameter to identify which item is being updated
        // For example, you can find the parent element and then find the related item in your data
    }

    // Function to load selected items on page load
    function loadSelectedItems() {
        var storedItems = localStorage.getItem('selectedItems');

        if (storedItems) {
            var parsedItems = JSON.parse(storedItems);

            // You can use parsedItems to add the item details to the cart as needed
            showDetails(document.getElementById('shop'), parsedItems.name, parsedItems.restaurant, parsedItems.image, parsedItems.price);
        }
    }

    // Call loadSelectedItems on page load
    window.onload = loadSelectedItems;

</script>
        
<script>
    function showRestaurantDetails(restaurantName) {
        // Make an AJAX request to fetch the restaurant details
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function () {
            if (xhr.readyState == 4 && xhr.status == 200) {
                // Update the content area with the fetched details within the opened tab
                document.getElementById("restaurantDetailsContainer").innerHTML = xhr.responseText;
            }
        };
        xhr.open("GET", "fetch_restaurant_details.php?restaurant_name=" + restaurantName, true);
        xhr.send();
    }
</script>
<script>
    
</script>
</body>
</html>
<script>
function updateItems(element, amount) {
    // Find the parent div of the clicked element
    var parentDiv = element.closest('.checkout_details');

    // Find the elements within the parent div
    var numberCounter = parentDiv.querySelector('.number_counter');
    var priceElement = parentDiv.querySelector('.food_details > div:nth-child(2)');
    var totalElement = parentDiv.querySelector('.total'); // New total div

    // Get the current count
    var currentCount = parseInt(numberCounter.textContent) || 0;

    // Update the count
    var newCount = currentCount + amount;
    numberCounter.textContent = newCount;

    // Extract the price as a number
    var priceText = priceElement.textContent.trim();
    var priceMatch = priceText.match(/(\d+(\.\d+)?)/); // Use regular expression to find numeric part
    var price = priceMatch ? parseFloat(priceMatch[0]) : 0;

    // Update the total for the current item
    var totalAmount = newCount * price;
    totalElement.textContent = 'Total: Ksh ' + totalAmount.toFixed(2); // Format to two decimal places

    // Calculate the total for all items in the cart
    updateTotalAmount();

    console.log("Count Updated:", newCount);
    console.log("Total Amount Updated:", totalAmount);
}

function updateTotalAmount() {
    // Find all total elements for each item in the cart
    var totalElements = document.querySelectorAll('.checkout_details .total');

    // Calculate the total amount for all items in the cart
    var totalCartAmount = 0;
    totalElements.forEach(function (totalElement) {
        totalCartAmount += parseFloat(totalElement.textContent.replace('Total: Ksh ', '').trim()) || 0;
    });

    // Update the original amount element outside the parent div with the total amount
    var amountElement = document.querySelector('.amount');
    amountElement.textContent = 'Ksh '+ totalCartAmount.toFixed(2); // Format to two decimal places

    // Update .iprice div with the total amount
    var ipriceElement = document.querySelector('.iprice');
    ipriceElement.textContent = 'Ksh '+totalCartAmount.toFixed(2);

    // Add delivery cost to the total amount
    var deliveryCost = parseFloat(document.querySelector('.deliv').textContent.replace('Delivery: Ksh ', '').trim()) || 0;
    var totalWithDelivery = totalCartAmount + deliveryCost;

    // Update .tota div with the total amount including delivery cost
    var totaElement = document.querySelector('.tota');
    totaElement.textContent = 'Ksh ' + totalWithDelivery.toFixed(2);

    // Update .totalpay element with the same total amount
    var totalpayElement = document.querySelector('.totalpay');
    totalpayElement.textContent = 'Ksh ' + totalWithDelivery.toFixed(2);
    document.getElementById("amountToPay").value=totalWithDelivery;

    console.log("Total Cart Amount Updated:", totalCartAmount);
}
</script>
<!-- handeldates -->
<script>
// Get the current date
var currentDate = new Date();

// Add 30 minutes to the current date
currentDate.setMinutes(currentDate.getMinutes() + 30);

// Update the estdate element with the modified date
document.getElementById('estdate').innerText = currentDate.toString();
</script>
<!-- handle change address -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Get the change address button
    var changeAddressButton = document.getElementById('change_address_button');

    // Add click event listener
    changeAddressButton.addEventListener('click', function() {
        // Show the address update form
        document.getElementById('address_update_form').style.display = 'block';
    });
});
</script>

<script>
    function openPaymentForm(){
        document.getElementById('paymentform').style.display = 'flex'
        document.getElementById('cartorder').style.width = '0%'
    }
</script>

