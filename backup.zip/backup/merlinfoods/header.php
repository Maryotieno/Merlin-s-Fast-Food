<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="static/index.css">
    <script src="static/script.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    
</head>
<body>
<div class="main_area">
        <div class="top_nav">
            <div class="menu_bar" >
                <i class="fa fa-bars" onclick="sidenav()"></i>
            </div>
            
            <div class="company_name"  id="hidename">
                Merlin Foods
            </div>
            <div class="retaurant_header" id="showname">
                Serve from Top Restaurants
            </div>
            <div class="foods_content_header"id="search">
                <input type="text"  id="food_search" placeholder="Search foods" onkeyup="searchFoods()" placeholder="Search foods">
                <i class="fa fa-search"></i>
            </div>
            <ul id="hidemenu">
                <li <a href="#" ">Home</a></li>
                <li onclick="showContent('service')">Services</li>
                <li onclick="showContent('restaurants')">Restaurants</li>
                <li onclick="showContent('foods')">Foods</li>
                <!-- <li onclick="showContent('about')">About us</li> -->
                <li onclick="showContent('contact')">Contacts</li>
                <li><a href="admin.php"> admin login</a></li>
            </ul>
</body>
</html>