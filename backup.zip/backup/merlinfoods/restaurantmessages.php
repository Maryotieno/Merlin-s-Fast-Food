<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>messages</title>
</head>
<body>
    <?php
    include "base.php"
    ?>
    <div class="main_bar">
    <div class="tab_content active" id="messagesContent">
                <div class="top_bar">
                <div class="bar_name">
                        messages
                    </div>
                </div>
                <div class="messages_area">
                <?php
                    include 'db_connection.php';
                    if(isset($_SESSION['restaurant_name'])) {
                        $restaurantName = $_SESSION['restaurant_name'];
                        try {
                            $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
                            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                            $sql = "SELECT `message_id`, `restaurant_name`, `sender_email`, `message_content`, `timestamp` FROM `messages` WHERE `restaurant_name` = :restaurant_name";
                            $stmt = $conn->prepare($sql);
                            $stmt->bindParam(':restaurant_name', $restaurantName);
                            $stmt->execute();
                            $messages = $stmt->fetchAll(PDO::FETCH_ASSOC);
                        } catch(PDOException $e) {
                            echo "Error: " . $e->getMessage();
                        }
                        $conn = null;
                    } else {
                        echo "Restaurant name not set in session.";
                    }
                    ?>

                    <?php if (!empty($messages)): ?>
                        <?php foreach ($messages as $message): ?>
                            <div class="messages_containers">
                                <div style="padding:3px;height:15%;">
                                    <div style="display:flex;gap :10px;">
                                        <p style="color:brown;">From </p><p><?php echo $message['sender_email']; ?></p>
                                    </div>
                                    <p  style="color:brown;"><?php echo $message['timestamp']; ?></p>
                                </div>
                                <div class="message">
                                    <?php echo $message['message_content']; ?>
                                </div>
                                <div class="message_footer">
                                    <a href="delete_message.php?message_id=<?php echo $message['message_id']; ?>">Delete message</a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="no_messages">
                            No messages for you.
                        </div>
                    <?php endif; ?>


                </div>
            </div>

    </div>
</body>
</html>