<?php
session_start();

// Check if the user is logged in using the 'email' session variable
if (isset($_SESSION['email'])) {
    // Destroy the session
    session_destroy();

    // Redirect to the index page or any other desired location
    header("Location: index.php");
    exit();
} else {
    // If the user is not logged in, you can handle it accordingly
    // For example, redirect them to the login page
    header("Location: index.php");
    exit();
}
?>
