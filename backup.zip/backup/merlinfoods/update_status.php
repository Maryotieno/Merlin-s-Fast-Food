<?php
session_start();
include('db_connection.php');

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the cartID and status from the form
    $cartID = $_POST['cartID'];
    $status = $_POST['status'];

    // Update the status in the database
    $sql = "UPDATE cart SET status = '$status' WHERE cartID = '$cartID'";

    if ($conn->query($sql) === TRUE) {
        header("Location: sellerorders.php?success = Status updated successfully.");
    } else {
        header("Location: sellerorders.php?error = error");
    }
} else {
    echo "Invalid request.";
}

// Close the database connection
$conn->close();
?>
